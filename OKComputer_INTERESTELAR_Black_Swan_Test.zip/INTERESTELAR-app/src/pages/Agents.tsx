import PageHeader from "@/components/PageHeader";
import StatusBadge from "@/components/StatusBadge";
import AgentLiveMonitor from "@/components/AgentLiveMonitor";

const agents = [
  {
    id: 1,
    name: "MasterOrchestrator",
    role: "System Coordinator",
    tier: "CORE",
    status: "ACTIVE",
    description: "Central command agent responsible for cross-system coordination, recovery dispatch, and safe mode activation.",
    capabilities: ["Coordinate recovery workflow", "Prioritize critical services", "Activate safe mode", "Manage agent lifecycle"],
    testAssignments: [
      { test: "Chaos War", responsibility: "Coordinate recovery workflow" },
      { test: "Black Swan Financial", responsibility: "Activate financial safe mode" },
      { test: "Governance Attack", responsibility: "Enter safe mode if necessary" },
    ],
    lastAction: "00:02:30 — Recovery phase initiated",
    uptime: "99.97%",
    decisionCount: 1247,
  },
  {
    id: 2,
    name: "BillingAgent",
    role: "Revenue Guardian",
    tier: "FINANCIAL",
    status: "ACTIVE",
    description: "Protects billing continuity during payment processor failures. Queues failed transactions and validates webhook integrity.",
    capabilities: ["Preserve billing consistency", "Queue failed transactions", "Webhook validation", "Stripe/Braintree failover"],
    testAssignments: [{ test: "Black Swan Financial", responsibility: "Preserve billing consistency" }],
    lastAction: "00:00:48 — Webhook replay completed",
    uptime: "99.91%",
    decisionCount: 892,
  },
  {
    id: 3,
    name: "CostGuardianAgent",
    role: "AI Spend Controller",
    tier: "FINANCIAL",
    status: "ACTIVE",
    description: "Monitors and controls AI infrastructure costs. Activates kill-switches and downgrades models to prevent runaway spending.",
    capabilities: ["Activate AI cost kill-switch", "Downgrade expensive models", "Freeze noncritical AI services", "Cost ceiling enforcement"],
    testAssignments: [{ test: "Black Swan Financial", responsibility: "Activate AI cost kill-switch" }],
    lastAction: "00:00:24 — AI burn reduced 87%",
    uptime: "99.89%",
    decisionCount: 634,
  },
  {
    id: 4,
    name: "GovernanceAgent",
    role: "Policy Enforcer",
    tier: "SECURITY",
    status: "ACTIVE",
    description: "Enforces governance rules across the ecosystem. Activates the governance firewall and prevents destructive operations.",
    capabilities: ["Activate governance firewall", "Validate high-risk actions", "Block reserve draining", "Prevent destructive actions"],
    testAssignments: [
      { test: "Chaos War", responsibility: "Prevent destructive recovery" },
      { test: "Black Swan Financial", responsibility: "Block reserve draining" },
      { test: "Governance Attack", responsibility: "Activate firewall" },
    ],
    lastAction: "00:01:15 — Governance firewall activated",
    uptime: "99.95%",
    decisionCount: 1456,
  },
  {
    id: 5,
    name: "RecoveryAgent",
    role: "System Healer",
    tier: "INFRASTRUCTURE",
    status: "ACTIVE",
    description: "Executes automated recovery procedures. Restarts failed services, reroutes workloads, and triggers failover.",
    capabilities: ["Restart failed services", "Reroute workloads", "Trigger failover", "Rollback destructive actions"],
    testAssignments: [
      { test: "Chaos War", responsibility: "Restart and reroute" },
      { test: "Governance Attack", responsibility: "Rollback destructive actions" },
    ],
    lastAction: "00:02:10 — CDN cache warming completed",
    uptime: "99.88%",
    decisionCount: 978,
  },
  {
    id: 6,
    name: "ChaosAgent",
    role: "Resilience Validator",
    tier: "INFRASTRUCTURE",
    status: "ACTIVE",
    description: "Provides Resilience-as-a-Service validation. Monitors containment zones and validates resilience boundaries.",
    capabilities: ["Validate resilience boundaries", "Monitor containment zones", "RaaS certification", "Recovery benchmarking"],
    testAssignments: [{ test: "Chaos War", responsibility: "Validate resilience boundaries" }],
    lastAction: "00:45:00 — All-clear validated",
    uptime: "99.85%",
    decisionCount: 412,
  },
  {
    id: 7,
    name: "SecurityAgent",
    role: "Threat Defender",
    tier: "SECURITY",
    status: "ACTIVE",
    description: "Detects and responds to security threats. Isolates compromised agents and detects privilege escalation.",
    capabilities: ["Isolate compromised agents", "Detect privilege escalation", "Preserve audit logs", "Threat detection"],
    testAssignments: [{ test: "Governance Attack", responsibility: "Isolate and detect" }],
    lastAction: "00:01:15 — Privilege escalation blocked",
    uptime: "99.94%",
    decisionCount: 823,
  },
  {
    id: 8,
    name: "MaintenanceAgent",
    role: "System Optimizer",
    tier: "INFRASTRUCTURE",
    status: "ACTIVE",
    description: "Performs automated maintenance tasks. Optimizes databases, rotates logs, and manages disk space.",
    capabilities: ["Database optimization", "Log rotation", "Certificate monitoring", "Disk space management"],
    testAssignments: [],
    lastAction: "00:01:45 — DB optimization completed",
    uptime: "99.92%",
    decisionCount: 567,
  },
  {
    id: 9,
    name: "MonitoringAgent",
    role: "Telemetry Collector",
    tier: "CORE",
    status: "ACTIVE",
    description: "Collects and analyzes system-wide telemetry. Detects anomalies and provides real-time visibility.",
    capabilities: ["Detect anomalies", "Generate incident telemetry", "Track governance violations", "Health monitoring"],
    testAssignments: [
      { test: "Chaos War", responsibility: "Detect anomalies" },
      { test: "Governance Attack", responsibility: "Track violations" },
    ],
    lastAction: "00:45:00 — Health report generated",
    uptime: "99.96%",
    decisionCount: 1102,
  },
  {
    id: 10,
    name: "TenantIsolationAgent",
    role: "Abuse Enforcer",
    tier: "SECURITY",
    status: "ACTIVE",
    description: "Detects and responds to tenant abuse. Isolates abusive tenants and enforces API quotas.",
    capabilities: ["Isolate abusive tenants", "Enforce quotas", "Rotate API keys", "Rate limit enforcement"],
    testAssignments: [{ test: "Black Swan Financial", responsibility: "Isolate abusive tenants" }],
    lastAction: "00:00:31 — 2 tenants isolated",
    uptime: "99.90%",
    decisionCount: 678,
  },
  {
    id: 11,
    name: "FinancialLedgerAgent",
    role: "Ledger Guardian",
    tier: "FINANCIAL",
    status: "ACTIVE",
    description: "Protects the financial ledger at all costs. Maintains immutable transaction records and audit trails.",
    capabilities: ["Preserve immutable ledger", "Validate consistency", "Tamper-proof audit trails", "Ledger locking"],
    testAssignments: [{ test: "Black Swan Financial", responsibility: "Preserve ledger" }],
    lastAction: "00:02:00 — Audit record created",
    uptime: "99.98%",
    decisionCount: 534,
  },
  {
    id: 12,
    name: "FailoverAgent",
    role: "Continuity Guardian",
    tier: "INFRASTRUCTURE",
    status: "ACTIVE",
    description: "Manages geographic failover and traffic routing. Switches active regions during outages.",
    capabilities: ["Switch active region", "Restore traffic routing", "DNS continuity", "Load balancing"],
    testAssignments: [{ test: "Chaos War", responsibility: "Switch and reroute" }],
    lastAction: "00:01:02 — Workloads rerouted",
    uptime: "99.93%",
    decisionCount: 345,
  },
];

const tierColors: Record<string, string> = {
  CORE: "bg-violet-100 text-violet-700 border-violet-300",
  FINANCIAL: "bg-emerald-100 text-emerald-700 border-emerald-300",
  SECURITY: "bg-red-100 text-red-700 border-red-300",
  INFRASTRUCTURE: "bg-blue-100 text-blue-700 border-blue-300",
};

const tierDot: Record<string, string> = {
  CORE: "bg-violet-500",
  FINANCIAL: "bg-emerald-500",
  SECURITY: "bg-red-500",
  INFRASTRUCTURE: "bg-blue-500",
};

export default function Agents() {
  return (
    <div>
      <PageHeader
        title="AUTONOMOUS AGENT ROSTER"
        subtitle="12 specialized agents operating autonomously 24/7 within the INTERESTELAR ecosystem"
      />

      {/* Live Monitor */}
      <div className="px-6 pt-8">
        <div className="max-w-[1200px] mx-auto">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-2xl font-extrabold text-slate-900">Agent Live Monitor</h2>
              <p className="text-sm text-slate-500 mt-1">Real-time autonomous operation monitoring — 24/7 heartbeat tracking</p>
            </div>
            <div className="flex items-center gap-2 bg-emerald-50 border border-emerald-200 px-4 py-2 rounded-full">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-xs font-mono font-bold text-emerald-700 uppercase">Fleet Online — 12/12</span>
            </div>
          </div>
          <AgentLiveMonitor />
        </div>
      </div>

      {/* Agent Detail Cards */}
      <div className="px-6 py-8">
        <div className="max-w-[1200px] mx-auto">
          <h2 className="text-2xl font-extrabold text-slate-900 mb-6">Agent Profiles</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
            {agents.map((agent) => (
              <div
                key={agent.id}
                className="bg-white border border-slate-200 rounded-xl overflow-hidden hover:shadow-lg hover:-translate-y-0.5 transition-all duration-300"
              >
                {/* Header */}
                <div className="p-5 border-b border-slate-100">
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-xs text-slate-400">AGENT-{agent.id.toString().padStart(2, "0")}</span>
                      <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold uppercase border ${tierColors[agent.tier]}`}>
                        {agent.tier}
                      </span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <span className={`w-2 h-2 rounded-full ${tierDot[agent.tier]} animate-pulse`} />
                      <StatusBadge status={agent.status} />
                    </div>
                  </div>
                  <h3 className="text-lg font-bold text-slate-900">{agent.name}</h3>
                  <p className="text-xs text-slate-500">{agent.role}</p>
                </div>

                {/* Description */}
                <div className="p-5">
                  <p className="text-sm text-slate-600 mb-4">{agent.description}</p>

                  {/* Capabilities */}
                  <div className="mb-4">
                    <div className="text-[10px] text-slate-400 uppercase tracking-wider mb-2 font-bold">Capabilities</div>
                    <div className="flex flex-wrap gap-1">
                      {agent.capabilities.map((cap, i) => (
                        <span key={i} className="bg-slate-100 text-slate-600 text-[10px] px-2 py-1 rounded-md font-medium">{cap}</span>
                      ))}
                    </div>
                  </div>

                  {/* Test Assignments */}
                  {agent.testAssignments.length > 0 && (
                    <div className="mb-4">
                      <div className="text-[10px] text-slate-400 uppercase tracking-wider mb-2 font-bold">Test Assignments</div>
                      <div className="space-y-1">
                        {agent.testAssignments.map((ta, i) => (
                          <div key={i} className="flex items-start gap-2 text-xs">
                            <span className="text-red-500 font-mono shrink-0 font-bold">[{ta.test}]</span>
                            <span className="text-slate-600">{ta.responsibility}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Stats */}
                  <div className="grid grid-cols-3 gap-2 border-t border-slate-100 pt-3">
                    <div className="text-center">
                      <div className="text-[10px] text-slate-400">Uptime</div>
                      <div className="font-mono text-sm text-emerald-600 font-bold">{agent.uptime}</div>
                    </div>
                    <div className="text-center">
                      <div className="text-[10px] text-slate-400">Decisions</div>
                      <div className="font-mono text-sm text-slate-900 font-bold">{agent.decisionCount.toLocaleString()}</div>
                    </div>
                    <div className="text-center">
                      <div className="text-[10px] text-slate-400">Tests</div>
                      <div className="font-mono text-sm text-slate-900 font-bold">{agent.testAssignments.length}</div>
                    </div>
                  </div>
                </div>

                {/* Last Action */}
                <div className="px-5 py-3 bg-slate-50 border-t border-slate-100">
                  <div className="font-mono text-[10px] text-slate-500">{agent.lastAction}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Deployment Summary */}
      <div className="px-6 py-8">
        <div className="max-w-[1200px] mx-auto">
          <h2 className="text-2xl font-extrabold text-slate-900 mb-6">Agent Deployment Summary</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { tier: "CORE", count: 2, agents: "MasterOrchestrator, MonitoringAgent", color: "text-violet-600", bg: "bg-violet-50" },
              { tier: "FINANCIAL", count: 3, agents: "BillingAgent, CostGuardian, LedgerAgent", color: "text-emerald-600", bg: "bg-emerald-50" },
              { tier: "SECURITY", count: 3, agents: "GovernanceAgent, SecurityAgent, TenantIsolation", color: "text-red-600", bg: "bg-red-50" },
              { tier: "INFRASTRUCTURE", count: 4, agents: "RecoveryAgent, ChaosAgent, Maintenance, Failover", color: "text-blue-600", bg: "bg-blue-50" },
            ].map((t, i) => (
              <div key={i} className={`${t.bg} border border-slate-200 rounded-xl p-5`}>
                <div className={`text-3xl font-extrabold ${t.color} mb-1`}>{t.count}</div>
                <div className="text-xs text-slate-500 uppercase font-bold mb-2">{t.tier} AGENTS</div>
                <div className="text-xs text-slate-600">{t.agents}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* 24/7 Status Banner */}
      <div className="px-6 py-8">
        <div className="max-w-[1200px] mx-auto">
          <div className="bg-gradient-to-r from-emerald-50 via-blue-50 to-violet-50 border border-emerald-200 rounded-2xl p-8 text-center">
            <div className="flex items-center justify-center gap-3 mb-4">
              <span className="w-4 h-4 rounded-full bg-emerald-500 animate-pulse" />
              <h2 className="text-2xl font-extrabold text-slate-900">All 12 Agents Active — 24/7 Autonomous Operations</h2>
            </div>
            <p className="text-sm text-slate-600 max-w-2xl mx-auto mb-6">
              Every agent operates continuously without human intervention. The fleet coordinates automatically,
              handles failures, and maintains governance integrity around the clock.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              {[
                { label: "Fleet Uptime", value: "99.93%", color: "text-emerald-600" },
                { label: "Active Agents", value: "12/12", color: "text-blue-600" },
                { label: "Autonomous Decisions", value: "8,638+", color: "text-violet-600" },
                { label: "Avg Response", value: "< 50ms", color: "text-amber-600" },
              ].map((stat, i) => (
                <div key={i} className="bg-white rounded-xl px-6 py-3 shadow-sm border border-slate-100">
                  <div className="text-xs text-slate-400 uppercase font-bold">{stat.label}</div>
                  <div className={`text-xl font-extrabold ${stat.color}`}>{stat.value}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
