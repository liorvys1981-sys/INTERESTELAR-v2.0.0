import { useState, useEffect, useRef } from "react";
import StatusBadge from "./StatusBadge";

interface Agent {
  id: number;
  name: string;
  tier: "CORE" | "FINANCIAL" | "SECURITY" | "INFRA";
  status: "ACTIVE" | "STANDBY" | "RECOVERING";
  uptime: string;
  cpu: number;
  memory: number;
  decisions: number;
  lastAction: string;
  nextAction: string;
  heartbeat: number; // ms since last beat
}

const initialAgents: Agent[] = [
  { id: 1, name: "MasterOrchestrator", tier: "CORE", status: "ACTIVE", uptime: "99.97%", cpu: 12, memory: 256, decisions: 1247, lastAction: "Coordinated failover sequence", nextAction: "Health check cycle", heartbeat: 0 },
  { id: 2, name: "BillingAgent", tier: "FINANCIAL", status: "ACTIVE", uptime: "99.91%", cpu: 8, memory: 128, decisions: 892, lastAction: "Processed 347 webhook replays", nextAction: "Invoice batch generation", heartbeat: 0 },
  { id: 3, name: "CostGuardianAgent", tier: "FINANCIAL", status: "ACTIVE", uptime: "99.89%", cpu: 15, memory: 192, decisions: 634, lastAction: "AI kill-switch activated (-87%)", nextAction: "Token burn monitoring", heartbeat: 0 },
  { id: 4, name: "GovernanceAgent", tier: "SECURITY", status: "ACTIVE", uptime: "99.95%", cpu: 5, memory: 64, decisions: 1456, lastAction: "Firewall rule validated", nextAction: "Permission boundary scan", heartbeat: 0 },
  { id: 5, name: "RecoveryAgent", tier: "INFRA", status: "ACTIVE", uptime: "99.88%", cpu: 22, memory: 320, decisions: 978, lastAction: "Redis cluster scaled 3→6", nextAction: "Cache warming verification", heartbeat: 0 },
  { id: 6, name: "ChaosAgent", tier: "INFRA", status: "ACTIVE", uptime: "99.85%", cpu: 35, memory: 512, decisions: 412, lastAction: "Resilience boundary validated", nextAction: "Chaos experiment #2847", heartbeat: 0 },
  { id: 7, name: "SecurityAgent", tier: "SECURITY", status: "ACTIVE", uptime: "99.94%", cpu: 10, memory: 160, decisions: 823, lastAction: "Privilege escalation blocked", nextAction: "Threat surface scan", heartbeat: 0 },
  { id: 8, name: "MaintenanceAgent", tier: "INFRA", status: "ACTIVE", uptime: "99.92%", cpu: 6, memory: 96, decisions: 567, lastAction: "DB optimization completed", nextAction: "Log rotation cycle", heartbeat: 0 },
  { id: 9, name: "MonitoringAgent", tier: "CORE", status: "ACTIVE", uptime: "99.96%", cpu: 18, memory: 224, decisions: 1102, lastAction: "Anomaly detected in queue", nextAction: "Telemetry flush", heartbeat: 0 },
  { id: 10, name: "TenantIsolationAgent", tier: "SECURITY", status: "ACTIVE", uptime: "99.90%", cpu: 9, memory: 128, decisions: 678, lastAction: "2 tenants isolated", nextAction: "Abuse pattern scan", heartbeat: 0 },
  { id: 11, name: "FinancialLedgerAgent", tier: "FINANCIAL", status: "ACTIVE", uptime: "99.98%", cpu: 7, memory: 112, decisions: 534, lastAction: "12,409 entries reconciled", nextAction: "Ledger integrity audit", heartbeat: 0 },
  { id: 12, name: "FailoverAgent", tier: "INFRA", status: "ACTIVE", uptime: "99.93%", cpu: 11, memory: 176, decisions: 345, lastAction: "Workloads rerouted US-East→West", nextAction: "DNS health check", heartbeat: 0 },
];

const tierConfig = {
  CORE: { bg: "bg-violet-50", border: "border-violet-200", text: "text-violet-700", badge: "bg-violet-100 text-violet-700", dot: "bg-violet-500" },
  FINANCIAL: { bg: "bg-emerald-50", border: "border-emerald-200", text: "text-emerald-700", badge: "bg-emerald-100 text-emerald-700", dot: "bg-emerald-500" },
  SECURITY: { bg: "bg-red-50", border: "border-red-200", text: "text-red-700", badge: "bg-red-100 text-red-700", dot: "bg-red-500" },
  INFRA: { bg: "bg-blue-50", border: "border-blue-200", text: "text-blue-700", badge: "bg-blue-100 text-blue-700", dot: "bg-blue-500" },
};

const actionLogs = [
  "Anomaly pattern detected",
  "Autonomous decision executed",
  "Cross-reference validation",
  "Failover sequence initiated",
  "Governance rule enforced",
  "Health check passed",
  "Incident correlation complete",
  "Metric threshold adjusted",
  "Model prediction updated",
  "Priority queue reordered",
  "Resource allocation optimized",
  "Signal correlation matched",
  "Telemetry batch processed",
  "Threat signature blocked",
  "Workflow state updated",
];

export default function AgentLiveMonitor() {
  const [agents, setAgents] = useState<Agent[]>(initialAgents);
  const [globalOps, setGlobalOps] = useState(0);
  const intervalRef = useRef<ReturnType<typeof setInterval>>();

  useEffect(() => {
    intervalRef.current = setInterval(() => {
      setAgents(prev => prev.map(agent => {
        const cpuDelta = (Math.random() - 0.5) * 4;
        const memDelta = (Math.random() - 0.5) * 8;
        const newCpu = Math.max(2, Math.min(45, agent.cpu + cpuDelta));
        const newMem = Math.max(32, Math.min(600, agent.memory + memDelta));
        const newHeartbeat = Math.floor(Math.random() * 200);
        const shouldUpdateAction = Math.random() > 0.85;

        return {
          ...agent,
          cpu: Math.round(newCpu * 10) / 10,
          memory: Math.round(newMem),
          heartbeat: newHeartbeat,
          decisions: agent.decisions + (Math.random() > 0.7 ? 1 : 0),
          ...(shouldUpdateAction ? {
            lastAction: agent.nextAction,
            nextAction: actionLogs[Math.floor(Math.random() * actionLogs.length)],
          } : {}),
        };
      }));
      setGlobalOps(prev => prev + Math.floor(Math.random() * 3) + 1);
    }, 1500);

    return () => clearInterval(intervalRef.current);
  }, []);

  const allActive = agents.every(a => a.status === "ACTIVE");
  const avgCpu = (agents.reduce((s, a) => s + a.cpu, 0) / agents.length).toFixed(1);
  const totalDecisions = agents.reduce((s, a) => s + a.decisions, 0);

  return (
    <div className="space-y-6">
      {/* Global Status */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm">
          <div className="flex items-center gap-2 mb-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-xs text-slate-400 uppercase font-bold tracking-wider">Fleet Status</span>
          </div>
          <div className="text-2xl font-extrabold text-slate-900">12/12</div>
          <div className="text-xs text-emerald-600 font-medium">{allActive ? "ALL ACTIVE" : "DEGRADED"}</div>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm">
          <div className="text-xs text-slate-400 uppercase font-bold tracking-wider mb-2">Autonomous Ops</div>
          <div className="text-2xl font-extrabold text-slate-900">{totalDecisions.toLocaleString()}</div>
          <div className="text-xs text-emerald-600 font-medium">+{globalOps} this session</div>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm">
          <div className="text-xs text-slate-400 uppercase font-bold tracking-wider mb-2">Avg CPU</div>
          <div className="text-2xl font-extrabold text-slate-900">{avgCpu}%</div>
          <div className="text-xs text-blue-600 font-medium">Optimal range</div>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm">
          <div className="text-xs text-slate-400 uppercase font-bold tracking-wider mb-2">Uptime</div>
          <div className="text-2xl font-extrabold text-slate-900">99.93%</div>
          <div className="text-xs text-emerald-600 font-medium">24/7 autonomous</div>
        </div>
      </div>

      {/* Agent Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {agents.map((agent) => {
          const tc = tierConfig[agent.tier];
          return (
            <div key={agent.id} className={`${tc.bg} border ${tc.border} rounded-xl p-4 hover:shadow-md transition-all`}>
              {/* Header */}
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-2">
                  <div className="relative">
                    <span className={`w-3 h-3 rounded-full ${tc.dot} inline-block`} />
                    <span className={`absolute inset-0 w-3 h-3 rounded-full ${tc.dot} animate-ping opacity-40`} />
                  </div>
                  <div>
                    <div className="text-sm font-bold text-slate-900 leading-tight">{agent.name}</div>
                    <div className="font-mono text-[10px] text-slate-400">AGENT-{String(agent.id).padStart(2, "0")}</div>
                  </div>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className={`text-[9px] px-1.5 py-0.5 rounded-full font-bold ${tc.badge}`}>{agent.tier}</span>
                  <StatusBadge status="ACTIVE" />
                </div>
              </div>

              {/* Metrics */}
              <div className="grid grid-cols-3 gap-2 mb-3">
                <div className="bg-white/60 rounded-lg p-2 text-center">
                  <div className="text-[10px] text-slate-400">CPU</div>
                  <div className="font-mono text-xs font-bold text-slate-700">{agent.cpu.toFixed(1)}%</div>
                  <div className="h-1 bg-slate-100 rounded-full mt-1 overflow-hidden">
                    <div className={`h-full ${tc.dot} rounded-full transition-all`} style={{ width: `${Math.min(100, agent.cpu * 2)}%` }} />
                  </div>
                </div>
                <div className="bg-white/60 rounded-lg p-2 text-center">
                  <div className="text-[10px] text-slate-400">Memory</div>
                  <div className="font-mono text-xs font-bold text-slate-700">{agent.memory}MB</div>
                  <div className="h-1 bg-slate-100 rounded-full mt-1 overflow-hidden">
                    <div className={`h-full ${tc.dot} rounded-full transition-all`} style={{ width: `${Math.min(100, (agent.memory / 600) * 100)}%` }} />
                  </div>
                </div>
                <div className="bg-white/60 rounded-lg p-2 text-center">
                  <div className="text-[10px] text-slate-400">Decisions</div>
                  <div className="font-mono text-xs font-bold text-slate-700">{agent.decisions.toLocaleString()}</div>
                </div>
              </div>

              {/* Activity Stream */}
              <div className="space-y-1.5">
                <div className="flex items-center gap-2">
                  <svg className="w-3 h-3 text-emerald-500 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
                  <span className="text-[11px] text-slate-600 truncate">{agent.lastAction}</span>
                </div>
                <div className="flex items-center gap-2">
                  <svg className="w-3 h-3 text-blue-400 shrink-0 animate-spin" style={{ animationDuration: "3s" }} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" /></svg>
                  <span className="text-[11px] text-blue-600 truncate">{agent.nextAction}</span>
                </div>
              </div>

              {/* Footer */}
              <div className="flex items-center justify-between mt-3 pt-2 border-t border-slate-100/50">
                <div className="flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                  <span className="font-mono text-[10px] text-emerald-600 font-bold">{agent.uptime}</span>
                </div>
                <span className="font-mono text-[10px] text-slate-400">beat: {agent.heartbeat}ms</span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
