import { useTranslation } from "react-i18next";
import { Link } from "react-router";
import StatusBadge from "@/components/StatusBadge";

const planKeyMap: Record<string, string> = {
  "Starter": "starter",
  "Growth": "growth",
  "Professional": "professional",
  "Enterprise": "enterprise",
};

const offices = [
  { key: "gateway", rank: 1, name: "API Gateway Office", desc: "Multi-tenant API management, routing & auth", price: 88, priceLabel: "$88/mo", img: "/assets/office-gateway.jpg", color: "from-blue-500 to-blue-700", features: ["Multi-tenant routing", "Rate limiting", "Auth management", "99.99% uptime"] },
  { key: "orchestration", rank: 2, name: "Orchestration Office", desc: "Event-driven workflow automation at scale", price: 88, priceLabel: "$88/mo", img: "/assets/hero-office.jpg", color: "from-violet-500 to-violet-700", features: ["Event-driven workflows", "1M+ events/day", "Custom triggers", "Real-time sync"] },
  { key: "billing", rank: 3, name: "Billing & Metering Office", desc: "Usage tracking and automated invoicing", price: 88, priceLabel: "$88/mo", img: "/assets/office-billing.jpg", color: "from-emerald-500 to-emerald-700", features: ["Usage tracking", "Auto-invoicing", "Multi-currency", "Revenue analytics"] },
  { key: "observability", rank: 4, name: "Observability Office", desc: "Real-time telemetry and monitoring dashboards", price: 499, priceLabel: "$499/mo", img: "/assets/office-analytics.jpg", color: "from-cyan-500 to-cyan-700", features: ["Real-time dashboards", "Alert management", "Log aggregation", "90-day retention"] },
  { key: "chaos", rank: 5, name: "Chaos Engineering Lab", desc: "Resilience-as-a-Service validation", price: 499, priceLabel: "$499/mo", img: "/assets/office-chaos.jpg", color: "from-orange-500 to-orange-700", features: ["RaaS validation", "SLA certification", "Stress testing", "Recovery benchmarks"] },
  { key: "stripe", rank: 6, name: "Stripe Automation Office", desc: "Payment processing automation & billing", price: 88, priceLabel: "$88/mo", img: "/assets/financial-office.jpg", color: "from-indigo-500 to-indigo-700", features: ["Payment automation", "Subscription billing", "Webhook handling", "Failover support"] },
  { key: "workflow", rank: 7, name: "Workflow Engine Office", desc: "Autonomous business process automation", price: 499, priceLabel: "$499/mo", img: "/assets/office-workflow.jpg", color: "from-pink-500 to-pink-700", features: ["Business automation", "Custom agents", "Process optimization", "Integration hub"] },
  { key: "analytics", rank: 8, name: "Analytics Office", desc: "Predictive insights and forecasting", price: 499, priceLabel: "$499/mo", img: "/assets/office-analytics.jpg", color: "from-teal-500 to-teal-700", features: ["Predictive models", "Trend analysis", "Custom reports", "Data export"] },
  { key: "aiEstimator", rank: 9, name: "AI Estimation Office", desc: "Intelligent cost and damage estimation", price: 1999, priceLabel: "$1,999/mo", img: "/assets/office-security.jpg", color: "from-amber-500 to-amber-700", features: ["Cost estimation", "Risk assessment", "Impact analysis", "ROI forecasting"] },
  { key: "support", rank: 10, name: "Customer Support Office", desc: "Autonomous customer service operations", price: 499, priceLabel: "$499/mo", img: "/assets/hero-office.jpg", color: "from-sky-500 to-sky-700", features: ["Ticket automation", "Knowledge base", "Multi-channel", "24/7 coverage"] },
  { key: "operations", rank: 11, name: "Autonomous Operations Center", desc: "Full-stack autonomous management", price: 4599, priceLabel: "$4,599/mo", img: "/assets/command-center.jpg", color: "from-slate-500 to-slate-700", features: ["Full-stack automation", "Resource optimization", "Capacity planning", "Cost governance"] },
  { key: "legal", rank: 12, name: "Legal Compliance Office", desc: "AI-powered regulatory compliance", price: 1999, priceLabel: "$1,999/mo", img: "/assets/crisis-room.jpg", color: "from-rose-500 to-rose-700", features: ["Compliance monitoring", "Policy enforcement", "Audit trails", "Risk alerts"] },
];

const pricing = [
  {
    name: "Starter",
    price: 88,
    desc: "For startups & small teams",
    color: "border-slate-200",
    popular: false,
    features: [
      "1 AI Office active",
      "1,000 API calls/day",
      "Community support",
      "99.5% SLA",
      "Basic analytics",
      "Email support",
    ],
    cta: "Start Free Trial",
  },
  {
    name: "Growth",
    price: 499,
    desc: "For growing companies",
    color: "border-slate-200",
    popular: false,
    features: [
      "3 AI Offices active",
      "100K API calls/day",
      "Stripe billing included",
      "99.9% SLA",
      "Advanced analytics",
      "Slack + Email support",
    ],
    cta: "Start Free Trial",
  },
  {
    name: "Professional",
    price: 1999,
    desc: "For mid-market enterprises",
    color: "border-blue-400",
    popular: true,
    features: [
      "8 AI Offices active",
      "Unlimited API calls",
      "Chaos Engineering included",
      "99.95% SLA",
      "Predictive analytics",
      "Priority support + CSM",
      "Custom integrations",
    ],
    cta: "Contact Sales",
  },
  {
    name: "Enterprise",
    price: 4599,
    desc: "For large organizations",
    color: "border-slate-200",
    popular: false,
    features: [
      "All 12 AI Offices",
      "Unlimited everything",
      "Custom autonomous agents",
      "99.99% SLA",
      "Private cloud option",
      "24/7 phone support",
      "SOC 2 compliance",
      "White-label available",
    ],
    cta: "Contact Sales",
  },
];

const testimonials = [
  { name: "Sarah Chen", role: "CTO", company: "CloudOps Pro", text: "INTERESTELAR replaced 6 contractors. Our API Gateway Office handles 2M requests daily with zero downtime." },
  { name: "Michael Torres", role: "VP Engineering", company: "SaaS Analytics Corp", text: "The Billing Office automated our entire invoicing pipeline. Saved $45K/month in manual processing costs." },
  { name: "Aisha Patel", role: "Head of Infrastructure", company: "DataStream Inc", text: "Chaos Engineering Lab found 14 critical weaknesses before our IPO audit. Worth every penny." },
  { name: "James Wilson", role: "CFO", company: "FinTech Solutions", text: "Financial Defense saved us during a 45-minute payment processor outage. Autonomous recovery in 47 seconds." },
];

const metrics = [
  { value: "12", label: "AI Offices", sub: "Specialized departments" },
  { value: "$3.25M", label: "Annual Revenue", sub: "Projected ARR" },
  { value: "99.93%", label: "Uptime", sub: "24/7 autonomous" },
  { value: "250+", label: "Customers", sub: "Across 15 countries" },
];

const faqs = [
  { q: "How do the AI Offices work?", a: "Each AI Office is a specialized autonomous agent that handles a specific business function — from API management to compliance monitoring. They operate 24/7 without human intervention, making decisions and executing tasks independently." },
  { q: "Can I start with one Office and add more later?", a: "Absolutely. Start with any single Office on the Starter plan ($88/mo) and upgrade to add more as your needs grow. You can activate additional Offices at any time." },
  { q: "Is there a free trial?", a: "Yes — every plan includes a 14-day free trial with full access to all included Offices. No credit card required to start." },
  { q: "How does autonomous recovery work?", a: "Our 12-agent fleet includes self-healing capabilities. If any Office encounters an issue, the RecoveryAgent and MasterOrchestrator coordinate an automatic response — often resolving problems before you notice them." },
  { q: "Can I customize the agents for my business?", a: "Enterprise customers get custom autonomous agents tailored to their specific workflows. Contact our sales team to discuss custom development." },
  { q: "What compliance certifications do you have?", a: "INTERESTELAR is SOC 2 Type II compliant, with Enterprise Certification and validated Chaos Engineering practices. Audit reports available on request." },
];

export default function LandingPage() {
  const { t } = useTranslation();

  return (
    <div className="min-h-screen bg-[#F8FAFC]">
      {/* ── Navigation ── */}
      <nav className="fixed top-0 left-0 right-0 z-50 h-16 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-sm">
        <div className="max-w-[1200px] mx-auto px-6 h-full flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 to-blue-700 flex items-center justify-center">
              <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" />
              </svg>
            </div>
            <span className="text-slate-900 font-extrabold text-base tracking-tight">INTERESTELAR</span>
          </div>
          <div className="hidden md:flex items-center gap-6">
            <a href="#services" className="text-sm text-slate-600 hover:text-slate-900 transition-colors font-medium">Services</a>
            <a href="#pricing" className="text-sm text-slate-600 hover:text-slate-900 transition-colors font-medium">Pricing</a>
            <a href="#testimonials" className="text-sm text-slate-600 hover:text-slate-900 transition-colors font-medium">Customers</a>
            <a href="#faq" className="text-sm text-slate-600 hover:text-slate-900 transition-colors font-medium">FAQ</a>
            <Link to="/dashboard" className="text-sm text-blue-600 hover:text-blue-700 font-semibold">Sign In</Link>
            <a href="#pricing" className="bg-blue-600 hover:bg-blue-700 text-white text-sm font-bold px-5 py-2.5 rounded-xl transition-colors shadow-sm">
              Start Free Trial
            </a>
          </div>
        </div>
      </nav>

      {/* ── Hero ── */}
      <div className="pt-20 pb-16 px-6">
        <div className="max-w-[1200px] mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="inline-flex items-center gap-2 bg-blue-50 border border-blue-200 px-4 py-2 rounded-full mb-6">
                <span className="w-2 h-2 rounded-full bg-blue-500 animate-pulse" />
                <span className="text-xs font-bold text-blue-700">12 AI Offices — 24/7 Autonomous Operations</span>
              </div>
              <h1 className="text-5xl md:text-6xl font-extrabold tracking-tight text-slate-900 mb-6 leading-tight">
                Your Autonomous<br />
                <span className="bg-gradient-to-r from-blue-600 to-violet-600 bg-clip-text text-transparent">AI Workforce</span>
              </h1>
              <p className="text-lg text-slate-500 mb-8 max-w-lg">
                Deploy 12 specialized AI departments that work autonomously 24/7. From API management to financial governance — your complete enterprise team, powered by AI.
              </p>
              <div className="flex flex-wrap gap-4">
                <a href="#pricing" className="bg-blue-600 hover:bg-blue-700 text-white font-bold px-8 py-3.5 rounded-xl transition-colors shadow-md text-center">
                  Start Free Trial
                </a>
                <a href="#services" className="bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 font-bold px-8 py-3.5 rounded-xl transition-colors text-center">
                  Explore Services
                </a>
              </div>
              <div className="flex items-center gap-6 mt-8">
                {metrics.slice(0, 3).map((m, i) => (
                  <div key={i}>
                    <div className="text-xl font-extrabold text-slate-900">{m.value}</div>
                    <div className="text-xs text-slate-500">{m.label}</div>
                  </div>
                ))}
              </div>
            </div>
            <div className="rounded-2xl overflow-hidden shadow-xl border border-slate-200">
              <img src="/assets/hero-office.jpg" alt="AI Team Collaboration" className="w-full h-80 lg:h-96 object-cover" />
            </div>
          </div>
        </div>
      </div>

      {/* ── Metrics Bar ── */}
      <div className="bg-white border-y border-slate-200 py-10 px-6">
        <div className="max-w-[1200px] mx-auto grid grid-cols-2 md:grid-cols-4 gap-8">
          {metrics.map((m, i) => (
            <div key={i} className="text-center">
              <div className="text-3xl md:text-4xl font-extrabold bg-gradient-to-r from-blue-600 to-violet-600 bg-clip-text text-transparent">{m.value}</div>
              <div className="text-sm font-semibold text-slate-700 mt-1">{m.label}</div>
              <div className="text-xs text-slate-400">{m.sub}</div>
            </div>
          ))}
        </div>
      </div>

      {/* ── 24/7 Agent Status Banner ── */}
      <div className="bg-gradient-to-r from-emerald-500 to-teal-600 py-4 px-6">
        <div className="max-w-[1200px] mx-auto flex items-center justify-center gap-6 md:gap-12 flex-wrap">
          <div className="flex items-center gap-2">
            <span className="relative flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-white opacity-75" />
              <span className="relative inline-flex rounded-full h-3 w-3 bg-white" />
            </span>
            <span className="text-white font-extrabold text-sm">12 AGENTS ACTIVE 24/7</span>
          </div>
          <div className="flex items-center gap-6 text-white/80 text-xs font-medium">
            <span>99.93% Uptime</span>
            <span className="w-1 h-1 rounded-full bg-white/50" />
            <span>Autonomous Decisions: 8,357</span>
            <span className="w-1 h-1 rounded-full bg-white/50 hidden md:inline" />
            <span className="hidden md:inline">Zero Human Intervention</span>
          </div>
          <Link to="/dashboard" className="bg-white/20 hover:bg-white/30 text-white text-xs font-bold px-4 py-2 rounded-lg transition-colors flex items-center gap-1.5">
            <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
            </svg>
            Monitor Live
          </Link>
        </div>
      </div>

      {/* ── Services (12 AI Offices) ── */}
      <div id="services" className="py-20 px-6">
        <div className="max-w-[1200px] mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-extrabold text-slate-900 mb-4">12 AI Offices</h2>
            <p className="text-lg text-slate-500 max-w-2xl mx-auto">
              Each Office is an autonomous department powered by AI. Activate the ones you need — they work 24/7 without human intervention.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
            {offices.map((office) => (
              <div key={office.key} className="bg-white border border-slate-200 rounded-xl overflow-hidden hover:shadow-lg hover:-translate-y-1 transition-all duration-300 group flex flex-col">
                <div className="h-40 overflow-hidden relative">
                  <img src={office.img} alt={office.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                  <div className={`absolute inset-0 bg-gradient-to-t ${office.color} opacity-20`} />
                  <div className="absolute top-3 left-3">
                    <span className="bg-white/90 backdrop-blur text-xs font-bold text-slate-700 px-2.5 py-1 rounded-lg shadow-sm">Rank #{office.rank}</span>
                  </div>
                  <div className="absolute top-3 right-3">
                    <span className="bg-slate-900/80 backdrop-blur text-white text-xs font-bold px-3 py-1.5 rounded-lg shadow-sm">{office.priceLabel}</span>
                  </div>
                </div>
                <div className="p-5 flex-1 flex flex-col">
                  <h3 className="text-base font-bold text-slate-900 mb-1">{office.name}</h3>
                  <p className="text-xs text-slate-500 mb-3">{office.desc}</p>
                  <div className="flex flex-wrap gap-1.5 mb-4">
                    {office.features.map((f, i) => (
                      <span key={i} className="text-[10px] bg-slate-100 text-slate-600 px-2 py-1 rounded-md font-medium">{f}</span>
                    ))}
                  </div>
                  <div className="mt-auto pt-3 border-t border-slate-100 flex items-center justify-between gap-3">
                    <div className="text-lg font-extrabold bg-gradient-to-r from-blue-600 to-violet-600 bg-clip-text text-transparent">{office.priceLabel}</div>
                    <Link
                      to={`/checkout?plan=${office.price <= 88 ? "starter" : office.price <= 499 ? "growth" : office.price <= 1999 ? "professional" : "enterprise"}&office=${office.key}`}
                      className="bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold px-4 py-2 rounded-lg transition-colors shadow-sm flex items-center gap-1.5"
                    >
                      <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />
                      </svg>
                      Subscribe
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ── Why Choose Us ── */}
      <div className="bg-white py-20 px-6 border-y border-slate-200">
        <div className="max-w-[1200px] mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-extrabold text-slate-900 mb-4">Why INTERESTELAR?</h2>
            <p className="text-lg text-slate-500">The only platform with a complete autonomous AI workforce</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { icon: "M13 10V3L4 14h7v7l9-11h-7z", title: "Autonomous 24/7", desc: "Our 12 AI agents operate continuously without human intervention. They detect issues, make decisions, and execute recovery — all in real-time." },
              { icon: "M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z", title: "Save 60-90% on Costs", desc: "Replace expensive contractor teams with autonomous AI departments. Our customers save an average of $45K per month on operational costs." },
              { icon: "M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z", title: "Enterprise-Grade Security", desc: "SOC 2 Type II compliant with governance firewall, audit trails, and automated threat detection. Your data and operations are always protected." },
              { icon: "M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z", title: "99.93% Uptime Guaranteed", desc: "Our autonomous recovery systems resolve failures in under 60 seconds. During the Black Swan stress test, all 10 simultaneous failures were contained." },
              { icon: "M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z", title: "Scale Instantly", desc: "Activate new AI Offices in seconds. From 1 to 12 departments — scale your AI workforce as your business grows without hiring." },
              { icon: "M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z", title: "Proven in Production", desc: "250+ customers across 15 countries. $3.25M ARR. Our platform survived the Black Swan Cascade — 10 simultaneous catastrophic events with zero data loss." },
            ].map((item, i) => (
              <div key={i} className="bg-slate-50 border border-slate-200 rounded-xl p-6 hover:shadow-md transition-all">
                <div className="w-12 h-12 rounded-xl bg-blue-50 flex items-center justify-center mb-4">
                  <svg className="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d={item.icon} /></svg>
                </div>
                <h3 className="text-lg font-bold text-slate-900 mb-2">{item.title}</h3>
                <p className="text-sm text-slate-500">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ── Pricing ── */}
      <div id="pricing" className="py-20 px-6">
        <div className="max-w-[1200px] mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-extrabold text-slate-900 mb-4">Simple Pricing</h2>
            <p className="text-lg text-slate-500">Start free. Scale as you grow. No hidden fees.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {pricing.map((tier, i) => (
              <div key={i} className={`bg-white border-2 ${tier.popular ? "border-blue-400 shadow-lg" : "border-slate-200"} rounded-xl overflow-hidden hover:shadow-xl transition-all flex flex-col`}>
                {tier.popular && (
                  <div className="bg-gradient-to-r from-blue-500 to-blue-600 text-white text-center text-xs font-bold py-2 uppercase tracking-wider">
                    Most Popular
                  </div>
                )}
                <div className="p-6 flex-1">
                  <h3 className="text-xl font-bold text-slate-900">{tier.name}</h3>
                  <p className="text-xs text-slate-500 mb-4">{tier.desc}</p>
                  <div className="text-4xl font-extrabold text-slate-900 mb-1">${tier.price}<span className="text-lg text-slate-400">/mo</span></div>
                  <p className="text-xs text-slate-400 mb-6">Billed annually or monthly</p>
                  <ul className="space-y-2.5 mb-6">
                    {tier.features.map((f, j) => (
                      <li key={j} className="flex items-start gap-2 text-sm text-slate-600">
                        <svg className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
                        {f}
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="px-6 pb-6">
                  <Link
                    to={`/checkout?plan=${planKeyMap[tier.name] || "starter"}`}
                    className={`block w-full text-center py-3 rounded-xl font-bold text-sm transition-colors ${
                      tier.popular
                        ? "bg-blue-600 hover:bg-blue-700 text-white shadow-md"
                        : "bg-slate-100 hover:bg-slate-200 text-slate-700"
                    }`}
                  >
                    {tier.cta}
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ── Testimonials ── */}
      <div id="testimonials" className="bg-white py-20 px-6 border-y border-slate-200">
        <div className="max-w-[1200px] mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-extrabold text-slate-900 mb-4">Trusted by 250+ Teams</h2>
            <p className="text-lg text-slate-500">See what our customers say about their AI workforce</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {testimonials.map((t, i) => (
              <div key={i} className="bg-slate-50 border border-slate-200 rounded-xl p-6">
                <svg className="w-8 h-8 text-blue-200 mb-3" fill="currentColor" viewBox="0 0 24 24"><path d="M14.017 21v-7.391c0-5.704 3.731-9.57 8.983-10.609l.995 2.151c-2.432.917-3.995 3.638-3.995 5.849h4v10h-9.983zm-14.017 0v-7.391c0-5.704 3.748-9.57 9-10.609l.996 2.151c-2.433.917-3.996 3.638-3.996 5.849h3.983v10h-9.983z" /></svg>
                <p className="text-slate-700 mb-4 text-sm leading-relaxed">{t.text}</p>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-400 to-violet-500 flex items-center justify-center text-white font-bold text-sm">
                    {t.name.charAt(0)}
                  </div>
                  <div>
                    <div className="text-sm font-bold text-slate-900">{t.name}</div>
                    <div className="text-xs text-slate-500">{t.role}, {t.company}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ── FAQ ── */}
      <div id="faq" className="py-20 px-6">
        <div className="max-w-[800px] mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-extrabold text-slate-900 mb-4">Frequently Asked Questions</h2>
          </div>
          <div className="space-y-4">
            {faqs.map((faq, i) => (
              <details key={i} className="bg-white border border-slate-200 rounded-xl group">
                <summary className="flex items-center justify-between p-5 cursor-pointer list-none">
                  <span className="text-sm font-bold text-slate-900">{faq.q}</span>
                  <svg className="w-5 h-5 text-slate-400 group-open:rotate-180 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" /></svg>
                </summary>
                <div className="px-5 pb-5 text-sm text-slate-600 leading-relaxed">{faq.a}</div>
              </details>
            ))}
          </div>
        </div>
      </div>

      {/* ── Final CTA ── */}
      <div className="bg-gradient-to-r from-blue-600 to-violet-600 py-20 px-6">
        <div className="max-w-[800px] mx-auto text-center">
          <h2 className="text-4xl font-extrabold text-white mb-4">Ready to Deploy Your AI Workforce?</h2>
          <p className="text-lg text-blue-100 mb-8 max-w-xl mx-auto">
            Start your 14-day free trial today. No credit card required. Full access to all AI Offices on your plan.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <a href="#pricing" className="bg-white hover:bg-slate-100 text-blue-600 font-bold px-10 py-4 rounded-xl transition-colors shadow-lg text-lg">
              Start Free Trial
            </a>
            <Link to="/dashboard" className="bg-blue-700 hover:bg-blue-800 text-white border border-blue-400 font-bold px-10 py-4 rounded-xl transition-colors text-lg">
              View Dashboard
            </Link>
          </div>
        </div>
      </div>

      {/* ── Footer ── */}
      <footer className="bg-slate-900 text-slate-400 py-16 px-6">
        <div className="max-w-[1200px] mx-auto">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-12">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 to-blue-700 flex items-center justify-center">
                  <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" />
                  </svg>
                </div>
                <span className="text-white font-extrabold">INTERESTELAR</span>
              </div>
              <p className="text-xs">Autonomous AI workforce for enterprises. 12 specialized departments operating 24/7.</p>
            </div>
            <div>
              <h4 className="text-white font-bold text-sm mb-3">Services</h4>
              <ul className="space-y-2 text-xs">
                <li><a href="#services" className="hover:text-white transition-colors">API Gateway</a></li>
                <li><a href="#services" className="hover:text-white transition-colors">Billing & Metering</a></li>
                <li><a href="#services" className="hover:text-white transition-colors">Chaos Engineering</a></li>
                <li><a href="#services" className="hover:text-white transition-colors">Workflow Engine</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-white font-bold text-sm mb-3">Company</h4>
              <ul className="space-y-2 text-xs">
                <li><a href="#" className="hover:text-white transition-colors">About</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Careers</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Blog</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Contact</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-white font-bold text-sm mb-3">Legal</h4>
              <ul className="space-y-2 text-xs">
                <li><a href="#" className="hover:text-white transition-colors">Privacy Policy</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Terms of Service</a></li>
                <li><a href="#" className="hover:text-white transition-colors">SOC 2 Compliance</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-slate-800 pt-6 flex flex-col md:flex-row items-center justify-between gap-4">
            <span className="text-xs">INTERESTELAR v2.0.0 — Autonomous Financial Governance Systems</span>
            <span className="text-xs">Made with AI for humans</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
