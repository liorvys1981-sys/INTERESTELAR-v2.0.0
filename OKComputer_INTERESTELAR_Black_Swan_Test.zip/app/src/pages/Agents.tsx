import PageHeader from "@/components/PageHeader";
import StatusBadge from "@/components/StatusBadge";
import AgentLiveMonitor from "@/components/AgentLiveMonitor";

/* ─── 8 Agents — Consolidated Architecture v2.1 ───
   FUSION A: GovernanceAgent + SecurityAgent → GovernanceSecurityAgent
   FUSION B: RecoveryAgent + FailoverAgent → ResilienceAgent
   FUSION C: ChaosAgent → MonitoringAgent sub-module (ChaosEngineering)
   FUSION D: MaintenanceAgent → ResilienceAgent sub-module
   PRESERVED: MasterOrchestrator, BillingAgent, CostGuardianAgent,
               FinancialLedgerAgent, TenantIsolationAgent, MonitoringAgent
   ─── */
const agents = [
  {
    id: 1, name: "MasterOrchestrator", role: "System Coordinator", tier: "CORE", status: "ACTIVE",
    description: "Central command agent responsible for cross-system coordination, recovery dispatch, and safe mode activation.",
    capabilities: ["Coordinate recovery workflow", "Prioritize critical services", "Activate safe mode", "Manage agent lifecycle"],
    testAssignments: [
      { test: "Chaos War", responsibility: "Coordinate recovery workflow" },
      { test: "Black Swan Financial", responsibility: "Activate financial safe mode" },
      { test: "Governance Attack", responsibility: "Enter safe mode if necessary" },
    ],
    lastAction: "00:02:30 — Recovery phase initiated", uptime: "99.99%", decisionCount: 1247,
  },
  {
    id: 2, name: "MonitoringAgent", role: "System Watcher + Chaos Mode", tier: "CORE", status: "ACTIVE",
    description: "Monitors all system components and agent activity. Detects anomalies, tracks metrics, and generates telemetry. INCLUDES ChaosEngineering validation module for resilience testing.",
    capabilities: ["Anomaly detection", "Metric tracking", "Telemetry generation", "Chaos experiment execution", "Resilience boundary validation"],
    testAssignments: [
      { test: "Chaos War", responsibility: "Detect anomalies + validate boundaries" },
      { test: "Governance Attack", responsibility: "Track governance violations" },
    ],
    lastAction: "00:00:05 — Anomaly detected + experiment #2847 queued", uptime: "99.98%", decisionCount: 1514,
  },
  {
    id: 3, name: "BillingAgent", role: "Revenue Guardian", tier: "FINANCIAL", status: "ACTIVE",
    description: "Protects billing continuity during payment processor failures. Queues failed transactions and validates webhook integrity.",
    capabilities: ["Preserve billing consistency", "Queue failed transactions", "Webhook validation", "Stripe/Braintree failover"],
    testAssignments: [{ test: "Black Swan Financial", responsibility: "Preserve billing consistency" }],
    lastAction: "00:00:48 — Webhook replay completed", uptime: "99.97%", decisionCount: 892,
  },
  {
    id: 4, name: "CostGuardianAgent", role: "AI Spend Controller", tier: "FINANCIAL", status: "ACTIVE",
    description: "Monitors and controls AI infrastructure costs. Activates kill-switches and downgrades models to prevent runaway spending. Independent circuit breaker.",
    capabilities: ["Activate AI cost kill-switch", "Downgrade expensive models", "Freeze noncritical AI services", "Cost ceiling enforcement"],
    testAssignments: [{ test: "Black Swan Financial", responsibility: "Activate AI cost kill-switch" }],
    lastAction: "00:00:24 — AI burn reduced 87%", uptime: "99.98%", decisionCount: 634,
  },
  {
    id: 5, name: "FinancialLedgerAgent", role: "Transaction Auditor", tier: "FINANCIAL", status: "ACTIVE",
    description: "Maintains the immutable financial ledger. Validates transaction consistency and preserves audit trails. Critical for tax compliance.",
    capabilities: ["Immutable ledger maintenance", "Transaction validation", "Audit trail preservation", "Tax compliance (1040-ES)"],
    testAssignments: [{ test: "Black Swan Financial", responsibility: "Preserve immutable ledger" }],
    lastAction: "00:00:33 — 12,409 entries reconciled", uptime: "99.99%", decisionCount: 534,
  },
  {
    id: 6, name: "TenantIsolationAgent", role: "Boundary Keeper", tier: "SECURITY", status: "ACTIVE",
    description: "Isolates tenants experiencing issues. Enforces quotas and prevents cross-tenant contamination. Critical for multi-tenant SaaS.",
    capabilities: ["Tenant isolation", "Quota enforcement", "Abusive tenant containment", "Resource reclamation"],
    testAssignments: [
      { test: "Chaos War", responsibility: "Tenant isolation" },
      { test: "Black Swan Financial", responsibility: "Isolate abusive tenants" },
    ],
    lastAction: "00:01:45 — 2 tenants isolated", uptime: "99.95%", decisionCount: 678,
  },
  {
    id: 7, name: "GovernanceSecurityAgent", role: "Policy Enforcer + Threat Detector", tier: "SECURITY", status: "ACTIVE",
    description: "FUSION: GovernanceAgent + SecurityAgent. Enforces governance rules AND detects security threats. Activates firewall, blocks privilege escalation, and prevents destructive operations.",
    capabilities: ["Activate governance firewall", "Privilege escalation detection", "Validate high-risk actions", "Block reserve draining", "Compromised agent isolation", "Audit log preservation"],
    testAssignments: [
      { test: "Chaos War", responsibility: "Prevent destructive recovery + security scan" },
      { test: "Black Swan Financial", responsibility: "Block reserve draining" },
      { test: "Governance Attack", responsibility: "Activate firewall + detect escalation" },
    ],
    lastAction: "00:01:15 — Firewall activated + privilege escalation blocked", uptime: "99.97%", decisionCount: 2279,
  },
  {
    id: 8, name: "ResilienceAgent", role: "System Healer + Traffic Router + Optimizer", tier: "INFRASTRUCTURE", status: "ACTIVE",
    description: "FUSION: RecoveryAgent + FailoverAgent + MaintenanceAgent. Executes recovery, manages traffic routing, performs health checks, AND runs preventive maintenance. Chaos validation module integrated.",
    capabilities: ["Restart failed services", "Reroute workloads", "Region switching", "DNS health checks", "Rollback destructive actions", "Database optimization", "Log rotation", "Preventive maintenance"],
    testAssignments: [
      { test: "Chaos War", responsibility: "Restart, reroute, switch region, validate" },
      { test: "Governance Attack", responsibility: "Rollback destructive actions" },
    ],
    lastAction: "00:02:10 — Recovery + cache warming + DB optimization", uptime: "99.97%", decisionCount: 1323,
  },
];

const tierColors: Record<string, string> = {
  CORE: "bg-violet-100 text-violet-700 border-violet-300",
  FINANCIAL: "bg-emerald-100 text-emerald-700 border-emerald-300",
  SECURITY: "bg-red-100 text-red-700 border-red-300",
  INFRASTRUCTURE: "bg-blue-100 text-blue-700 border-blue-300",
};

const tierDot: Record<string, string> = {
  CORE: "bg-violet-500",
  FINANCIAL: "bg-emerald-500",
  SECURITY: "bg-red-500",
  INFRASTRUCTURE: "bg-blue-500",
};

export default function Agents() {
  return (
    <div>
      <PageHeader title="AUTONOMOUS AGENT ROSTER" subtitle="8 consolidated agents (from 12) — Architecture v2.1 — 24/7 autonomous operations" />

      {/* Live Monitor */}
      <div className="px-6 pt-8">
        <div className="max-w-[1200px] mx-auto">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-2xl font-extrabold text-slate-900">Agent Live Monitor</h2>
              <p className="text-sm text-slate-500 mt-1">Real-time autonomous operation monitoring — Consolidated architecture v2.1</p>
            </div>
            <div className="flex items-center gap-2 bg-emerald-50 border border-emerald-200 px-4 py-2 rounded-full">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-xs font-mono font-bold text-emerald-700 uppercase">Fleet Online — 8/8</span>
            </div>
          </div>
          <AgentLiveMonitor />
        </div>
      </div>

      {/* Agent Detail Cards */}
      <div className="px-6 py-8">
        <div className="max-w-[1200px] mx-auto">
          <h2 className="text-2xl font-extrabold text-slate-900 mb-6">Agent Profiles</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
            {agents.map((agent) => (
              <div key={agent.id} className="bg-white border border-slate-200 rounded-xl overflow-hidden hover:shadow-lg hover:-translate-y-0.5 transition-all duration-300">
                {/* Header */}
                <div className="p-5 border-b border-slate-100">
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-xs text-slate-400">AGENT-{agent.id.toString().padStart(2, "0")}</span>
                      <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold uppercase border ${tierColors[agent.tier]}`}>{agent.tier}</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <span className={`w-2 h-2 rounded-full ${tierDot[agent.tier]} animate-pulse`} />
                      <StatusBadge status={agent.status} />
                    </div>
                  </div>
                  <h3 className="text-lg font-bold text-slate-900">{agent.name}</h3>
                  <p className="text-xs text-slate-500">{agent.role}</p>
                </div>
                {/* Description */}
                <div className="p-5">
                  <p className="text-sm text-slate-600 mb-4">{agent.description}</p>
                  {/* Capabilities */}
                  <div className="mb-4">
                    <div className="text-[10px] text-slate-400 uppercase tracking-wider mb-2 font-bold">Capabilities</div>
                    <div className="flex flex-wrap gap-1">
                      {agent.capabilities.map((cap, i) => (
                        <span key={i} className="bg-slate-100 text-slate-600 text-[10px] px-2 py-1 rounded-md font-medium">{cap}</span>
                      ))}
                    </div>
                  </div>
                  {/* Test Assignments */}
                  {agent.testAssignments.length > 0 && (
                    <div className="mb-4">
                      <div className="text-[10px] text-slate-400 uppercase tracking-wider mb-2 font-bold">Test Assignments</div>
                      <div className="space-y-1">
                        {agent.testAssignments.map((ta, i) => (
                          <div key={i} className="flex items-start gap-2 text-xs">
                            <span className="text-red-500 font-mono shrink-0 font-bold">[{ta.test}]</span>
                            <span className="text-slate-600">{ta.responsibility}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                  {/* Stats */}
                  <div className="grid grid-cols-3 gap-2 border-t border-slate-100 pt-3">
                    <div className="text-center">
                      <div className="text-[10px] text-slate-400">Uptime</div>
                      <div className="font-mono text-sm text-emerald-600 font-bold">{agent.uptime}</div>
                    </div>
                    <div className="text-center">
                      <div className="text-[10px] text-slate-400">Decisions</div>
                      <div className="font-mono text-sm text-slate-900 font-bold">{agent.decisionCount.toLocaleString()}</div>
                    </div>
                    <div className="text-center">
                      <div className="text-[10px] text-slate-400">Tests</div>
                      <div className="font-mono text-sm text-slate-900 font-bold">{agent.testAssignments.length}</div>
                    </div>
                  </div>
                </div>
                {/* Last Action */}
                <div className="px-5 py-3 bg-slate-50 border-t border-slate-100">
                  <div className="font-mono text-[10px] text-slate-500">{agent.lastAction}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Deployment Summary */}
      <div className="px-6 py-8">
        <div className="max-w-[1200px] mx-auto">
          <h2 className="text-2xl font-extrabold text-slate-900 mb-6">Agent Deployment Summary</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { tier: "CORE", count: 2, agents: "MasterOrchestrator, MonitoringAgent (+Chaos)", color: "text-violet-600", bg: "bg-violet-50" },
              { tier: "FINANCIAL", count: 3, agents: "BillingAgent, CostGuardian, LedgerAgent", color: "text-emerald-600", bg: "bg-emerald-50" },
              { tier: "SECURITY", count: 2, agents: "TenantIsolation, GovernanceSecurity", color: "text-red-600", bg: "bg-red-50" },
              { tier: "INFRASTRUCTURE", count: 1, agents: "ResilienceAgent (+Recovery+Failover+Maint)", color: "text-blue-600", bg: "bg-blue-50" },
            ].map((t, i) => (
              <div key={i} className={`${t.bg} border border-slate-200 rounded-xl p-5`}>
                <div className={`text-3xl font-extrabold ${t.color} mb-1`}>{t.count}</div>
                <div className="text-xs text-slate-500 uppercase font-bold mb-2">{t.tier} AGENTS</div>
                <div className="text-xs text-slate-600">{t.agents}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Architecture Note */}
      <div className="px-6 py-4">
        <div className="max-w-[1200px] mx-auto">
          <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 text-center">
            <p className="text-xs text-amber-700 font-medium">
              <strong>Architecture v2.1:</strong> Consolidated from 12 to 8 agents via 3 controlled fusions.
              All 7 pillars preserved: Resilience, Auto-recovery, Failover, Security, Observability, Governance, Scalability.
            </p>
          </div>
        </div>
      </div>

      {/* 24/7 Status Banner */}
      <div className="px-6 py-8">
        <div className="max-w-[1200px] mx-auto">
          <div className="bg-gradient-to-r from-emerald-50 via-blue-50 to-violet-50 border border-emerald-200 rounded-2xl p-8 text-center">
            <div className="flex items-center justify-center gap-3 mb-4">
              <span className="w-4 h-4 rounded-full bg-emerald-500 animate-pulse" />
              <h2 className="text-2xl font-extrabold text-slate-900">8 Agents Active — 24/7 Autonomous Operations</h2>
            </div>
            <p className="text-sm text-slate-600 max-w-2xl mx-auto mb-6">
              Every agent operates continuously without human intervention. The consolidated fleet coordinates automatically,
              handles failures, and maintains governance integrity around the clock.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              {[
                { label: "Fleet Uptime", value: "99.93%", color: "text-emerald-600" },
                { label: "Active Agents", value: "8/8", color: "text-blue-600" },
                { label: "Autonomous Decisions", value: "7,921+", color: "text-violet-600" },
                { label: "Avg Response", value: "< 50ms", color: "text-amber-600" },
              ].map((stat, i) => (
                <div key={i} className="bg-white rounded-xl px-6 py-3 shadow-sm border border-slate-100">
                  <div className="text-xs text-slate-400 uppercase font-bold">{stat.label}</div>
                  <div className={`text-xl font-extrabold ${stat.color}`}>{stat.value}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
