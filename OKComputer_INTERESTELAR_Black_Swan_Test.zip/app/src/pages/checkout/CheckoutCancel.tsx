import { Link } from "react-router";

export default function CheckoutCancel() {
  return (
    <div className="min-h-screen bg-[#F8FAFC] flex items-center justify-center px-6">
      <div className="max-w-lg w-full text-center">
        <div className="w-20 h-20 rounded-full bg-amber-50 flex items-center justify-center mx-auto mb-6">
          <svg className="w-10 h-10 text-amber-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
        </div>

        <h1 className="text-3xl font-extrabold text-slate-900 mb-3">
          Checkout Cancelled
        </h1>

        <p className="text-slate-500 mb-2">
          No worries! Your card was not charged.
        </p>
        <p className="text-slate-400 text-sm mb-8">
          You can restart your subscription anytime. Your 14-day free trial is still waiting.
        </p>

        <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm mb-8">
          <h3 className="text-sm font-bold text-slate-900 mb-3">Need help deciding?</h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-center">
            <div className="bg-slate-50 rounded-lg p-3">
              <div className="text-lg font-extrabold text-blue-600">14 days</div>
              <div className="text-[10px] text-slate-500">Free trial</div>
            </div>
            <div className="bg-slate-50 rounded-lg p-3">
              <div className="text-lg font-extrabold text-blue-600">No card</div>
              <div className="text-[10px] text-slate-500">Required to start</div>
            </div>
            <div className="bg-slate-50 rounded-lg p-3">
              <div className="text-lg font-extrabold text-blue-600">Cancel</div>
              <div className="text-[10px] text-slate-500">Anytime</div>
            </div>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link
            to="/"
            className="bg-blue-600 hover:bg-blue-700 text-white font-bold px-8 py-3.5 rounded-xl transition-colors shadow-md inline-flex items-center justify-center gap-2"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
            </svg>
            Back to Pricing
          </Link>
          <a
            href="mailto:sales@interestelar.ai"
            className="bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 font-bold px-8 py-3.5 rounded-xl transition-colors inline-flex items-center justify-center gap-2"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
            </svg>
            Contact Sales
          </a>
        </div>
      </div>
    </div>
  );
}
