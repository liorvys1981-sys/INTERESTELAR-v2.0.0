import { useEffect, useState } from "react";
import { useSearchParams, Link } from "react-router";
import { trpc } from "@/providers/trpc";

export default function CheckoutSuccess() {
  const [searchParams] = useSearchParams();
  const sessionId = searchParams.get("session_id");
  const [countdown, setCountdown] = useState(5);

  const { data } = trpc.stripe.getSession.useQuery(
    { sessionId: sessionId || "" },
    { enabled: !!sessionId }
  );

  useEffect(() => {
    const timer = setInterval(() => {
      setCountdown((c) => {
        if (c <= 1) {
          clearInterval(timer);
          return 0;
        }
        return c - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const plan = data?.session?.plan || "your chosen plan";
  const planNames: Record<string, string> = {
    starter: "Starter",
    growth: "Growth",
    professional: "Professional",
    enterprise: "Enterprise",
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] flex items-center justify-center px-6">
      <div className="max-w-lg w-full text-center">
        <div className="w-20 h-20 rounded-full bg-emerald-50 flex items-center justify-center mx-auto mb-6">
          <svg className="w-10 h-10 text-emerald-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
          </svg>
        </div>

        <h1 className="text-3xl font-extrabold text-slate-900 mb-3">
          Welcome to INTERESTELAR!
        </h1>

        <p className="text-slate-500 mb-2">
          Your subscription to the <strong className="text-slate-900">{planNames[plan] || plan}</strong> plan is confirmed.
        </p>

        <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm mb-8 text-left">
          <h3 className="text-sm font-bold text-slate-900 mb-3">What happens next?</h3>
          <ul className="space-y-3">
            <li className="flex items-start gap-3 text-sm text-slate-600">
              <span className="w-6 h-6 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center text-xs font-bold shrink-0">1</span>
              Check your email for login credentials and onboarding instructions
            </li>
            <li className="flex items-start gap-3 text-sm text-slate-600">
              <span className="w-6 h-6 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center text-xs font-bold shrink-0">2</span>
              Your 12 AI Offices will be provisioned within 2 minutes
            </li>
            <li className="flex items-start gap-3 text-sm text-slate-600">
              <span className="w-6 h-6 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center text-xs font-bold shrink-0">3</span>
              Access your dashboard to activate and configure your AI workforce
            </li>
          </ul>
        </div>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link
            to="/dashboard"
            className="bg-blue-600 hover:bg-blue-700 text-white font-bold px-8 py-3.5 rounded-xl transition-colors shadow-md inline-flex items-center justify-center gap-2"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z" />
            </svg>
            Go to Dashboard
          </Link>
          <Link
            to="/"
            className="bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 font-bold px-8 py-3.5 rounded-xl transition-colors inline-flex items-center justify-center gap-2"
          >
            Back to Home
          </Link>
        </div>

        {countdown > 0 && (
          <p className="text-xs text-slate-400 mt-6">
            Redirecting to dashboard in {countdown} seconds...
          </p>
        )}
      </div>
    </div>
  );
}
