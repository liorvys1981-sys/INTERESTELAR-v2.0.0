import { useState, useMemo } from "react";

/* ─── Constants: Florida + Federal Tax 2025 ─── */
const SE_TAX_RATE = 0.153; // 15.3% (12.4% SS + 2.9% Medicare)
const SS_CAP = 184500;
const SS_RATE = 0.124;
const MEDICARE_RATE = 0.029;
const STRIPE_FEE_PCT = 0.029;
const STRIPE_FEE_FIXED = 0.30;
const QBI_DEDUCTION = 0.20; // 20% Qualified Business Income

// Federal brackets 2025 (single filer)
const federalBrackets = [
  { limit: 11925, rate: 0.10 },
  { limit: 48475, rate: 0.12 },
  { limit: 103350, rate: 0.22 },
  { limit: 197300, rate: 0.24 },
  { limit: 250525, rate: 0.32 },
  { limit: 626350, rate: 0.35 },
  { limit: Infinity, rate: 0.37 },
];

function calcFederalTax(taxableIncome: number): number {
  let tax = 0, prev = 0;
  for (const b of federalBrackets) {
    if (taxableIncome <= prev) break;
    const amount = Math.min(taxableIncome, b.limit) - prev;
    tax += amount * b.rate;
    prev = b.limit;
  }
  return tax;
}

/* ─── 12 Services Data ─── */
const services = [
  { key: "gateway", name: "API Gateway Office", price: 88, costIA: 12, costInfra: 15, clients: 15 },
  { key: "orchestration", name: "Orchestration Office", price: 88, costIA: 10, costInfra: 15, clients: 12 },
  { key: "billing", name: "Billing & Metering", price: 88, costIA: 8, costInfra: 12, clients: 18 },
  { key: "observability", name: "Observability Office", price: 499, costIA: 45, costInfra: 25, clients: 8 },
  { key: "chaos", name: "Chaos Engineering Lab", price: 499, costIA: 35, costInfra: 20, clients: 5 },
  { key: "stripe", name: "Stripe Automation", price: 88, costIA: 8, costInfra: 10, clients: 20 },
  { key: "workflow", name: "Workflow Engine", price: 499, costIA: 40, costInfra: 25, clients: 6 },
  { key: "analytics", name: "Analytics Office", price: 499, costIA: 50, costInfra: 30, clients: 7 },
  { key: "aiEstimator", name: "AI Estimation", price: 1999, costIA: 180, costInfra: 80, clients: 3 },
  { key: "support", name: "Customer Support", price: 499, costIA: 35, costInfra: 20, clients: 4 },
  { key: "operations", name: "Operations Center", price: 4599, costIA: 350, costInfra: 200, clients: 2 },
  { key: "legal", name: "Legal Compliance", price: 1999, costIA: 150, costInfra: 80, clients: 2 },
];

const months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];

// Simulated MRR growth data
const mrrData = [2800,4200,6800,9500,14200,19800,26500,34800,45200,58900,73400,92100];
const clientsData = [5,8,13,18,27,38,51,67,87,113,141,177];

export default function AdminFinances() {
  const [activeTab, setActiveTab] = useState<"overview" | "services" | "taxes" | "projections">("overview");

  /* ─── Computed Financials ─── */
  const financials = useMemo(() => {
    const totalRevenue = services.reduce((s, svc) => s + svc.price * svc.clients, 0);
    const totalCostIA = services.reduce((s, svc) => s + svc.costIA * svc.clients, 0);
    const totalCostInfra = services.reduce((s, svc) => s + svc.costInfra * svc.clients, 0);
    const totalStripeFees = services.reduce((s, svc) => {
      const transactions = svc.clients;
      return s + (svc.price * STRIPE_FEE_PCT + STRIPE_FEE_FIXED) * transactions;
    }, 0);
    const totalCost = totalCostIA + totalCostInfra + totalStripeFees;
    const grossProfit = totalRevenue - totalCost;
    const grossMargin = (grossProfit / totalRevenue) * 100;

    // Self-Employment Tax (15.3% on 92.35% of net earnings)
    const seTaxable = grossProfit * 0.9235;
    let seTax = 0;
    if (seTaxable <= SS_CAP) {
      seTax = seTaxable * SE_TAX_RATE;
    } else {
      seTax = SS_CAP * SS_RATE + seTaxable * MEDICARE_RATE;
    }

    // QBI Deduction (20%)
    const qbiDeduction = grossProfit * QBI_DEDUCTION;

    // Federal taxable income (after QBI deduction)
    const fedTaxableIncome = Math.max(0, grossProfit - qbiDeduction);
    const federalTax = calcFederalTax(fedTaxableIncome);

    // Total tax burden
    const totalTax = seTax + federalTax;
    const netProfit = grossProfit - totalTax;
    const netMargin = (netProfit / totalRevenue) * 100;
    const effectiveTaxRate = totalTax / grossProfit * 100;

    return {
      totalRevenue, totalCostIA, totalCostInfra, totalStripeFees,
      totalCost, grossProfit, grossMargin,
      seTax, qbiDeduction, federalTax, totalTax,
      netProfit, netMargin, effectiveTaxRate, fedTaxableIncome,
    };
  }, []);

  /* ─── Monthly Projection ─── */
  const projection = useMemo(() => {
    return months.map((m, i) => {
      const revenue = mrrData[i];
      const clients = clientsData[i];
      // Scale costs proportionally
      const costRatio = financials.totalCost / financials.totalRevenue;
      const costs = revenue * costRatio;
      const gross = revenue - costs;
      const seTaxable = gross * 0.9235;
      const seTax = seTaxable <= SS_CAP ? seTaxable * SE_TAX_RATE : SS_CAP * SS_RATE + seTaxable * MEDICARE_RATE;
      const qbiDed = gross * QBI_DEDUCTION;
      const fedTaxable = Math.max(0, gross - qbiDed);
      const fedTax = calcFederalTax(fedTaxable);
      const totalTax = seTax + fedTax;
      const net = gross - totalTax;
      return { month: m, revenue, clients, costs, gross, seTax, fedTax, totalTax, net };
    });
  }, [financials]);

  const totalAnnualRevenue = projection.reduce((s, p) => s + p.revenue, 0);
  const totalAnnualNet = projection.reduce((s, p) => s + p.net, 0);

  /* ─── Formatters ─── */
  const $ = (n: number) => n.toLocaleString("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 });
  const pct = (n: number) => n.toFixed(1) + "%";

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-extrabold text-slate-900">LGG AUTO SUPPLIES LLC — Financial Dashboard</h2>
          <p className="text-sm text-slate-500 mt-1">Tax compliance: Florida + Federal | EIN required | lggautosupplies@gmail.com</p>
        </div>
        <div className="text-right">
          <div className="text-2xl font-extrabold text-emerald-600">{$(financials.netProfit)}</div>
          <div className="text-xs text-slate-400">Net Profit / Month</div>
        </div>
      </div>

      {/* Sub-tabs */}
      <div className="flex gap-2 border-b border-slate-200 pb-0">
        {[
          { id: "overview" as const, label: "Overview", icon: "M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z" },
          { id: "services" as const, label: "By Service", icon: "M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" },
          { id: "taxes" as const, label: "Tax Breakdown", icon: "M9 14l6-6m-5.5.5h.01m5.99 5h.01M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16l3.5-2 3.5 2 3.5-2 3.5 2z" },
          { id: "projections" as const, label: "12-Month Projection", icon: "M7 12l3-3 3 3 4-4M8 21l4-4 4 4M3 4h18M4 4h16v12a1 1 0 01-1 1H5a1 1 0 01-1-1V4z" },
        ].map((t) => (
          <button key={t.id} onClick={() => setActiveTab(t.id)}
            className={`flex items-center gap-2 px-4 py-2.5 text-sm font-bold rounded-t-lg transition-colors border-b-2 ${
              activeTab === t.id
                ? "border-blue-600 text-blue-600 bg-blue-50/50"
                : "border-transparent text-slate-500 hover:text-slate-700 hover:bg-slate-50"
            }`}>
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d={t.icon} /></svg>
            {t.label}
          </button>
        ))}
      </div>

      {/* ─── OVERVIEW TAB ─── */}
      {activeTab === "overview" && (
        <div className="space-y-6">
          {/* Top KPIs */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { label: "MRR (Revenue)", value: $(financials.totalRevenue), color: "text-blue-600", bg: "bg-blue-50", sub: `${services.reduce((s,sv)=>s+sv.clients,0)} active clients` },
              { label: "Gross Profit", value: $(financials.grossProfit), color: "text-violet-600", bg: "bg-violet-50", sub: pct(financials.grossMargin) + " margin" },
              { label: "Total Tax (SE + Fed)", value: $(financials.totalTax), color: "text-amber-600", bg: "bg-amber-50", sub: pct(financials.effectiveTaxRate) + " effective" },
              { label: "NET PROFIT", value: $(financials.netProfit), color: "text-emerald-600", bg: "bg-emerald-50", sub: pct(financials.netMargin) + " net margin" },
            ].map((kpi, i) => (
              <div key={i} className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm">
                <div className="text-xs text-slate-500 font-semibold uppercase tracking-wider mb-2">{kpi.label}</div>
                <div className={`text-2xl font-extrabold ${kpi.color}`}>{kpi.value}</div>
                <div className="text-[11px] text-slate-400 mt-1">{kpi.sub}</div>
              </div>
            ))}
          </div>

          {/* Revenue Breakdown */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm">
              <h3 className="text-base font-bold text-slate-900 mb-4">Revenue Breakdown</h3>
              <div className="space-y-3">
                {[
                  { label: "Gross Revenue (MRR)", value: financials.totalRevenue, color: "bg-blue-500" },
                  { label: "Cost of Goods (IA APIs)", value: -financials.totalCostIA, color: "bg-red-400" },
                  { label: "Infrastructure Costs", value: -financials.totalCostInfra, color: "bg-orange-400" },
                  { label: "Stripe Processing Fees", value: -financials.totalStripeFees, color: "bg-purple-400" },
                  { label: "GROSS PROFIT", value: financials.grossProfit, color: "bg-violet-500", bold: true },
                  { label: "Self-Employment Tax (15.3%)", value: -financials.seTax, color: "bg-amber-400" },
                  { label: "Federal Income Tax", value: -financials.federalTax, color: "bg-amber-500" },
                  { label: "QBI Deduction (+20%)", value: financials.qbiDeduction, color: "bg-emerald-400", ded: true },
                  { label: "NET PROFIT", value: financials.netProfit, color: "bg-emerald-500", bold: true },
                ].map((item, i) => (
                  <div key={i} className={`flex items-center justify-between py-2 ${item.bold ? "border-t-2 border-slate-200 pt-3 mt-2" : "border-b border-slate-50"}`}>
                    <div className="flex items-center gap-2">
                      <div className={`w-3 h-3 rounded-full ${item.color}`} />
                      <span className={`text-sm ${item.bold ? "font-extrabold text-slate-900" : "text-slate-600"}`}>{item.label}</span>
                    </div>
                    <span className={`text-sm font-mono font-bold ${item.value < 0 ? "text-red-500" : item.ded ? "text-emerald-600" : item.bold ? "text-slate-900 text-base" : "text-slate-700"}`}>
                      {item.value < 0 ? "-" : "+"}{$(Math.abs(item.value))}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Tax Summary Card */}
            <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm">
              <h3 className="text-base font-bold text-slate-900 mb-4">Tax Obligations (2025)</h3>
              <div className="space-y-4">
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <div className="text-xs font-bold text-blue-700 uppercase mb-2">Florida State</div>
                  <div className="space-y-1 text-sm">
                    <div className="flex justify-between"><span className="text-slate-600">State Income Tax</span><span className="font-bold text-emerald-600">0.00% — FL exempt</span></div>
                    <div className="flex justify-between"><span className="text-slate-600">Sales Tax on SaaS</span><span className="font-bold text-emerald-600">0.00% — Exempt</span></div>
                    <div className="flex justify-between"><span className="text-slate-600">Annual Report Fee</span><span className="font-mono font-bold text-slate-700">$138.75/yr</span></div>
                  </div>
                </div>
                <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
                  <div className="text-xs font-bold text-amber-700 uppercase mb-2">Federal (IRS)</div>
                  <div className="space-y-1 text-sm">
                    <div className="flex justify-between"><span className="text-slate-600">Self-Employment Tax</span><span className="font-mono font-bold text-slate-700">{pct(SE_TAX_RATE * 92.35)}</span></div>
                    <div className="flex justify-between"><span className="text-slate-600">Social Security (12.4%)</span><span className="font-mono font-bold text-slate-700">Cap: ${SS_CAP.toLocaleString()}</span></div>
                    <div className="flex justify-between"><span className="text-slate-600">Medicare (2.9%)</span><span className="font-mono font-bold text-slate-700">No cap</span></div>
                    <div className="flex justify-between"><span className="text-slate-600">Federal Income Tax</span><span className="font-mono font-bold text-slate-700">10%-37% brackets</span></div>
                    <div className="flex justify-between"><span className="text-slate-600">QBI Deduction</span><span className="font-mono font-bold text-emerald-600">+{pct(QBI_DEDUCTION)}</span></div>
                  </div>
                </div>
                <div className="bg-slate-50 border border-slate-200 rounded-lg p-3">
                  <div className="text-xs text-slate-500 text-center">
                    <strong>Business Email:</strong> lggautosupplies@gmail.com
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ─── SERVICES TAB ─── */}
      {activeTab === "services" && (
        <div>
          <h3 className="text-base font-bold text-slate-900 mb-4">Margin by Service (12 AI Offices)</h3>
          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead><tr className="border-b border-slate-200 bg-slate-50">
                  {["Service","Price","Clients","MRR","Cost IA","Cost Infra","Stripe Fee","Gross Profit","Margin","Net*"].map(h =>
                    <th key={h} className="text-left font-mono text-[10px] text-slate-500 uppercase tracking-wider py-3 px-3">{h}</th>
                  )}
                </tr></thead>
                <tbody>
                  {services.map((svc, i) => {
                    const mrr = svc.price * svc.clients;
                    const stripeFee = (svc.price * STRIPE_FEE_PCT + STRIPE_FEE_FIXED) * svc.clients;
                    const totalCost = svc.costIA * svc.clients + svc.costInfra * svc.clients + stripeFee;
                    const gross = mrr - totalCost;
                    const margin = (gross / mrr) * 100;
                    const netEstimate = gross * 0.65; // rough after-tax estimate
                    return (
                      <tr key={i} className="border-b border-slate-100 hover:bg-slate-50 transition-colors">
                        <td className="py-3 px-3 text-sm font-bold text-slate-900">{svc.name}</td>
                        <td className="py-3 px-3 text-sm font-mono text-slate-700">${svc.price}</td>
                        <td className="py-3 px-3"><span className="text-xs font-bold bg-blue-50 text-blue-600 px-2 py-0.5 rounded-full">{svc.clients}</span></td>
                        <td className="py-3 px-3 text-sm font-mono font-bold text-blue-600">${mrr.toLocaleString()}</td>
                        <td className="py-3 px-3 text-xs font-mono text-red-500">-${(svc.costIA * svc.clients).toLocaleString()}</td>
                        <td className="py-3 px-3 text-xs font-mono text-orange-500">-${(svc.costInfra * svc.clients).toLocaleString()}</td>
                        <td className="py-3 px-3 text-xs font-mono text-purple-500">-${stripeFee.toFixed(0)}</td>
                        <td className="py-3 px-3 text-sm font-mono font-bold text-violet-600">${gross.toLocaleString()}</td>
                        <td className="py-3 px-3"><span className={`text-xs font-bold px-2 py-0.5 rounded-full ${margin >= 80 ? "bg-emerald-100 text-emerald-700" : margin >= 60 ? "bg-blue-100 text-blue-700" : "bg-amber-100 text-amber-700"}`}>{pct(margin)}</span></td>
                        <td className="py-3 px-3 text-sm font-mono font-bold text-emerald-600">${netEstimate.toLocaleString()}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
          <p className="text-[11px] text-slate-400 mt-2">* Net estimate = 65% of gross (after SE tax + federal tax approximation). Actual depends on total income bracket.</p>
        </div>
      )}

      {/* ─── TAXES TAB ─── */}
      {activeTab === "taxes" && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* SE Tax */}
            <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm">
              <h3 className="text-base font-bold text-slate-900 mb-3">Self-Employment Tax</h3>
              <div className="text-3xl font-extrabold text-amber-600 mb-1">{$(financials.seTax)}</div>
              <div className="text-xs text-slate-500 mb-4">per month</div>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between"><span className="text-slate-500">SE Taxable (92.35%)</span><span className="font-mono">{$(financials.grossProfit * 0.9235)}</span></div>
                <div className="flex justify-between"><span className="text-slate-500">Social Security (12.4%)</span><span className="font-mono">{$(Math.min(financials.grossProfit * 0.9235, SS_CAP) * SS_RATE)}</span></div>
                <div className="flex justify-between"><span className="text-slate-500">Medicare (2.9%)</span><span className="font-mono">{$(financials.grossProfit * 0.9235 * MEDICARE_RATE)}</span></div>
                <div className="flex justify-between"><span className="text-slate-500">SS Cap (2025)</span><span className="font-mono text-xs">${SS_CAP.toLocaleString()}</span></div>
              </div>
            </div>
            {/* Federal */}
            <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm">
              <h3 className="text-base font-bold text-slate-900 mb-3">Federal Income Tax</h3>
              <div className="text-3xl font-extrabold text-red-500 mb-1">{$(financials.federalTax)}</div>
              <div className="text-xs text-slate-500 mb-4">per month</div>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between"><span className="text-slate-500">Gross Profit</span><span className="font-mono">{$(financials.grossProfit)}</span></div>
                <div className="flex justify-between"><span className="text-slate-500">QBI Deduction (20%)</span><span className="font-mono text-emerald-600">-{$(financials.qbiDeduction)}</span></div>
                <div className="flex justify-between border-t border-slate-200 pt-2"><span className="text-slate-700 font-bold">Taxable Income</span><span className="font-mono font-bold">{$(financials.fedTaxableIncome)}</span></div>
              </div>
            </div>
            {/* Summary */}
            <div className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-xl p-6 shadow-md text-white">
              <h3 className="text-base font-bold mb-3">Total Tax Burden</h3>
              <div className="text-3xl font-extrabold text-amber-400 mb-1">{$(financials.totalTax)}</div>
              <div className="text-xs text-slate-400 mb-4">per month</div>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between"><span className="text-slate-300">Effective Tax Rate</span><span className="font-bold text-amber-400">{pct(financials.effectiveTaxRate)}</span></div>
                <div className="flex justify-between"><span className="text-slate-300">After-Tax Profit</span><span className="font-bold text-emerald-400">{$(financials.netProfit)}</span></div>
                <div className="flex justify-between"><span className="text-slate-300">Net Margin</span><span className="font-bold text-emerald-400">{pct(financials.netMargin)}</span></div>
              </div>
              <div className="mt-4 pt-3 border-t border-slate-700 text-[10px] text-slate-400">
                Florida: No state income tax<br/>
                SaaS: Exempt from sales tax<br/>
                LLC: Pass-through entity
              </div>
            </div>
          </div>

          {/* Federal Brackets Visual */}
          <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm">
            <h3 className="text-base font-bold text-slate-900 mb-4">2025 Federal Tax Brackets (Single Filer)</h3>
            <div className="space-y-2">
              {federalBrackets.map((b, i) => {
                const prev = i === 0 ? 0 : federalBrackets[i-1].limit;
                const inThisBracket = Math.max(0, Math.min(financials.fedTaxableIncome, b.limit) - prev);
                const pctFill = Math.min(100, (inThisBracket / (b.limit - prev)) * 100);
                const isActive = financials.fedTaxableIncome > prev;
                return (
                  <div key={i} className={`flex items-center gap-4 ${isActive ? "" : "opacity-40"}`}>
                    <div className="w-12 text-xs font-mono font-bold text-slate-500">{pct(b.rate)}</div>
                    <div className="flex-1 h-6 bg-slate-100 rounded-full overflow-hidden relative">
                      <div className="h-full bg-gradient-to-r from-blue-400 to-blue-600 rounded-full transition-all" style={{ width: `${isActive ? Math.max(5, pctFill) : 0}%` }} />
                      <span className="absolute inset-0 flex items-center px-3 text-[10px] font-mono text-slate-600">
                        ${prev.toLocaleString()} — {b.limit === Infinity ? "+" : "$" + b.limit.toLocaleString()}
                      </span>
                    </div>
                    {inThisBracket > 0 && <div className="w-20 text-xs font-mono font-bold text-blue-600">{$(inThisBracket * b.rate)}</div>}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* ─── PROJECTIONS TAB ─── */}
      {activeTab === "projections" && (
        <div className="space-y-6">
          {/* Annual Summary */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { label: "Annual Revenue", value: $(totalAnnualRevenue), color: "text-blue-600" },
              { label: "Annual Tax", value: $(projection.reduce((s,p)=>s+p.totalTax,0)), color: "text-amber-600" },
              { label: "Annual Net Profit", value: $(totalAnnualNet), color: "text-emerald-600" },
              { label: "Avg Net Margin", value: pct(totalAnnualNet / totalAnnualRevenue * 100), color: "text-violet-600" },
            ].map((kpi, i) => (
              <div key={i} className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm text-center">
                <div className="text-xs text-slate-500 font-semibold uppercase mb-2">{kpi.label}</div>
                <div className={`text-xl font-extrabold ${kpi.color}`}>{kpi.value}</div>
              </div>
            ))}
          </div>

          {/* Monthly Table */}
          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead><tr className="border-b border-slate-200 bg-slate-50">
                  {["Month","Clients","Revenue","Costs","Gross Profit","SE Tax","Fed Tax","Total Tax","NET PROFIT"].map(h =>
                    <th key={h} className="text-left font-mono text-[10px] text-slate-500 uppercase tracking-wider py-3 px-3">{h}</th>
                  )}
                </tr></thead>
                <tbody>
                  {projection.map((p, i) => (
                    <tr key={i} className="border-b border-slate-100 hover:bg-slate-50 transition-colors">
                      <td className="py-3 px-3 text-sm font-bold text-slate-900">{p.month}</td>
                      <td className="py-3 px-3"><span className="text-xs font-bold bg-blue-50 text-blue-600 px-2 py-0.5 rounded-full">{p.clients}</span></td>
                      <td className="py-3 px-3 text-sm font-mono font-bold text-blue-600">${p.revenue.toLocaleString()}</td>
                      <td className="py-3 px-3 text-xs font-mono text-red-500">-${p.costs.toFixed(0)}</td>
                      <td className="py-3 px-3 text-sm font-mono font-bold text-violet-600">${p.gross.toFixed(0)}</td>
                      <td className="py-3 px-3 text-xs font-mono text-amber-600">-${p.seTax.toFixed(0)}</td>
                      <td className="py-3 px-3 text-xs font-mono text-red-500">-${p.fedTax.toFixed(0)}</td>
                      <td className="py-3 px-3 text-xs font-mono font-bold text-amber-700">-${p.totalTax.toFixed(0)}</td>
                      <td className="py-3 px-3 text-sm font-mono font-bold text-emerald-600">${p.net.toFixed(0)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Chart Bar */}
          <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm">
            <h3 className="text-base font-bold text-slate-900 mb-4">Revenue vs Net Profit (12-Month)</h3>
            <div className="flex items-end gap-2 h-48">
              {projection.map((p, i) => {
                const maxRev = Math.max(...projection.map(x => x.revenue));
                const revH = (p.revenue / maxRev) * 100;
                const netH = (p.net / maxRev) * 100;
                return (
                  <div key={i} className="flex-1 flex flex-col items-center gap-1">
                    <div className="w-full flex flex-col items-center gap-px">
                      <div className="w-full bg-blue-400 rounded-t-sm" style={{ height: `${revH * 0.4}px` }} title={`Revenue: $${p.revenue.toLocaleString()}`} />
                      <div className="w-full bg-emerald-500 rounded-b-sm" style={{ height: `${netH * 0.4}px` }} title={`Net: $${p.net.toFixed(0)}`} />
                    </div>
                    <span className="text-[9px] text-slate-400 font-mono">{p.month}</span>
                  </div>
                );
              })}
            </div>
            <div className="flex items-center justify-center gap-6 mt-4 text-xs">
              <div className="flex items-center gap-1.5"><div className="w-3 h-3 bg-blue-400 rounded-sm" /><span className="text-slate-500">Revenue</span></div>
              <div className="flex items-center gap-1.5"><div className="w-3 h-3 bg-emerald-500 rounded-sm" /><span className="text-slate-500">Net Profit</span></div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
