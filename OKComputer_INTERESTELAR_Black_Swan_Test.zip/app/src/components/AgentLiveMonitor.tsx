import { useState, useEffect, useRef } from "react";
import StatusBadge from "./StatusBadge";

/* ────────────────────────────────────────────────
   INTERESTELAR v2.0.0 — Autonomous Agent Architecture
   LGG AUTO SUPPLIES LLC

   ARCHITECTURE: 8 agents (reduced from 12)
   FUSION A — GovernanceAgent + SecurityAgent = GovernanceSecurityAgent
   FUSION B — RecoveryAgent + FailoverAgent = ResilienceAgent
   FUSION C — ChaosAgent → resilience validation sub-module
   FUSION D — MaintenanceAgent → maintenance sub-module
   ──────────────────────────────────────────────── */

interface Agent {
  id: number;
  name: string;
  tier: "CORE" | "FINANCIAL" | "SECURITY" | "INFRASTRUCTURE";
  status: "ACTIVE" | "STANDBY" | "RECOVERING";
  uptime: string;
  cpu: number;
  memory: number;
  decisions: number;
  lastAction: string;
  nextAction: string;
  heartbeat: number;
  subModules?: string[];
}

/* ─── 8 Agents (post-consolidation) ─── */
const initialAgents: Agent[] = [
  /* ── CORE TIER ────────────────────────────── */
  {
    id: 1,
    name: "MasterOrchestrator",
    tier: "CORE",
    status: "ACTIVE",
    uptime: "99.99%",
    cpu: 12,
    memory: 256,
    decisions: 1247,
    lastAction: "Revenue orchestration completed",
    nextAction: "MRR growth optimization",
    heartbeat: 0,
  },
  {
    id: 2,
    name: "MonitoringAgent",
    tier: "CORE",
    status: "ACTIVE",
    uptime: "99.98%",
    cpu: 18,
    memory: 224,
    decisions: 1102,
    lastAction: "Net margin alert: 71% optimal",
    nextAction: "Cash flow prediction cycle",
    heartbeat: 0,
    subModules: ["ChaosEngineering"],
  },

  /* ── FINANCIAL TIER ───────────────────────── */
  {
    id: 3,
    name: "BillingAgent",
    tier: "FINANCIAL",
    status: "ACTIVE",
    uptime: "99.97%",
    cpu: 8,
    memory: 128,
    decisions: 892,
    lastAction: "Stripe payout $8,247 processed",
    nextAction: "Subscription renewal cycle",
    heartbeat: 0,
  },
  {
    id: 4,
    name: "CostGuardianAgent",
    tier: "FINANCIAL",
    status: "ACTIVE",
    uptime: "99.98%",
    cpu: 15,
    memory: 192,
    decisions: 634,
    lastAction: "SE tax reserve calculated (15.3%)",
    nextAction: "QBI deduction optimization",
    heartbeat: 0,
  },
  {
    id: 5,
    name: "FinancialLedgerAgent",
    tier: "FINANCIAL",
    status: "ACTIVE",
    uptime: "99.99%",
    cpu: 7,
    memory: 112,
    decisions: 534,
    lastAction: "Florida tax compliance: EXEMPT",
    nextAction: "Quarterly EST-1040 prep",
    heartbeat: 0,
  },

  /* ── SECURITY TIER ────────────────────────── */
  {
    id: 6,
    name: "TenantIsolationAgent",
    tier: "SECURITY",
    status: "ACTIVE",
    uptime: "99.95%",
    cpu: 9,
    memory: 128,
    decisions: 678,
    lastAction: "Revenue isolation per tenant",
    nextAction: "Multi-tenant billing audit",
    heartbeat: 0,
  },
  {
    id: 7,
    name: "GovernanceSecurityAgent",
    tier: "SECURITY",
    status: "ACTIVE",
    uptime: "99.97%",
    cpu: 10,
    memory: 180,
    decisions: 2279,
    lastAction: "Privilege escalation blocked + governance rule enforced",
    nextAction: "Security audit + compliance scan",
    heartbeat: 0,
  },

  /* ── INFRASTRUCTURE TIER ──────────────────── */
  {
    id: 8,
    name: "ResilienceAgent",
    tier: "INFRASTRUCTURE",
    status: "ACTIVE",
    uptime: "99.97%",
    cpu: 18,
    memory: 420,
    decisions: 1323,
    lastAction: "Client data backup verified + backup gateway ready",
    nextAction: "Disaster recovery drill + DB optimization",
    heartbeat: 0,
    subModules: ["Recovery", "Failover", "HealthChecks", "Maintenance"],
  },
];

const tierConfig = {
  CORE: { bg: "bg-violet-50", border: "border-violet-200", text: "text-violet-700", badge: "bg-violet-100 text-violet-700", dot: "bg-violet-500" },
  FINANCIAL: { bg: "bg-emerald-50", border: "border-emerald-200", text: "text-emerald-700", badge: "bg-emerald-100 text-emerald-700", dot: "bg-emerald-500" },
  SECURITY: { bg: "bg-red-50", border: "border-red-200", text: "text-red-700", badge: "bg-red-100 text-red-700", dot: "bg-red-500" },
  INFRASTRUCTURE: { bg: "bg-blue-50", border: "border-blue-200", text: "text-blue-700", badge: "bg-blue-100 text-blue-700", dot: "bg-blue-500" },
};

const actionLogs = [
  "Stripe charge processed successfully",
  "MRR growth +12% this month",
  "SE tax reserve allocated (15.3%)",
  "QBI deduction applied (+20%)",
  "Federal tax bracket calculated",
  "Florida sales tax: EXEMPT verified",
  "Subscription renewal confirmed",
  "Client payment method validated",
  "Revenue per client optimized",
  "Cost of goods tracked",
  "Net margin forecast updated",
  "Quarterly 1040-ES calculated",
  "Governance rule enforced + security scan",
  "Privilege escalation blocked",
  "Resilience boundary validated",
  "Recovery sequence completed",
  "Failover to backup region executed",
  "Health check passed",
  "DB optimization completed",
  "Log rotation cycle done",
  "Autonomous decision executed",
  "Anomaly pattern detected",
  "Threat signature blocked",
  "Incident correlation complete",
  "Metric threshold adjusted",
  "Model prediction updated",
  "Priority queue reordered",
  "Resource allocation optimized",
  "Signal correlation matched",
  "Telemetry batch processed",
  "Workflow state updated",
  "Tenant isolation enforced",
  "Audit trail preserved",
  "Compliance check verified",
];

export default function AgentLiveMonitor() {
  const [agents, setAgents] = useState<Agent[]>(initialAgents);
  const [globalOps, setGlobalOps] = useState(0);
  const intervalRef = useRef<ReturnType<typeof setInterval>>();

  useEffect(() => {
    intervalRef.current = setInterval(() => {
      setAgents(prev => prev.map(agent => {
        const cpuDelta = (Math.random() - 0.5) * 4;
        const memDelta = (Math.random() - 0.5) * 8;
        const newCpu = Math.max(2, Math.min(45, agent.cpu + cpuDelta));
        const newMem = Math.max(32, Math.min(600, agent.memory + memDelta));
        const newHeartbeat = Math.floor(Math.random() * 200);
        const shouldUpdateAction = Math.random() > 0.85;

        return {
          ...agent,
          cpu: Math.round(newCpu * 10) / 10,
          memory: Math.round(newMem),
          heartbeat: newHeartbeat,
          decisions: agent.decisions + (Math.random() > 0.7 ? 1 : 0),
          ...(shouldUpdateAction ? {
            lastAction: agent.nextAction,
            nextAction: actionLogs[Math.floor(Math.random() * actionLogs.length)],
          } : {}),
        };
      }));
      setGlobalOps(prev => prev + Math.floor(Math.random() * 3) + 1);
    }, 1500);

    return () => clearInterval(intervalRef.current);
  }, []);

  const allActive = agents.every(a => a.status === "ACTIVE");
  const avgCpu = (agents.reduce((s, a) => s + a.cpu, 0) / agents.length).toFixed(1);
  const totalDecisions = agents.reduce((s, a) => s + a.decisions, 0);

  return (
    <div className="space-y-6">
      {/* 24/7 Banner */}
      <div className="bg-gradient-to-r from-emerald-500 to-teal-600 rounded-xl p-4 text-white shadow-md flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="relative">
            <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
              <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <span className="absolute -top-0.5 -right-0.5 w-3 h-3 rounded-full bg-white animate-ping" />
            <span className="absolute -top-0.5 -right-0.5 w-3 h-3 rounded-full bg-white" />
          </div>
          <div>
            <div className="text-sm font-extrabold flex items-center gap-2">
              8 AGENTS ACTIVE 24/7 — ARCHITECTURE v2.1
              <span className="bg-white/20 text-[10px] px-2 py-0.5 rounded-full font-bold">AUTONOMOUS</span>
            </div>
            <div className="text-xs text-emerald-100 font-medium">
              Consolidated from 12 agents. All 7 pillars preserved. Zero human intervention required.
            </div>
          </div>
        </div>
        <div className="hidden md:flex items-center gap-3">
          <div className="text-center">
            <div className="text-lg font-extrabold">{totalDecisions.toLocaleString()}</div>
            <div className="text-[10px] text-emerald-100 uppercase">Decisions</div>
          </div>
          <div className="w-px h-8 bg-white/20" />
          <div className="text-center">
            <div className="text-lg font-extrabold">{avgCpu}%</div>
            <div className="text-[10px] text-emerald-100 uppercase">Avg CPU</div>
          </div>
          <div className="w-px h-8 bg-white/20" />
          <div className="text-center">
            <div className="text-lg font-extrabold">99.9%</div>
            <div className="text-[10px] text-emerald-100 uppercase">Uptime</div>
          </div>
        </div>
      </div>

      {/* Architecture Legend */}
      <div className="bg-slate-50 border border-slate-200 rounded-lg p-3 flex flex-wrap items-center gap-4 text-xs text-slate-500">
        <span className="font-bold text-slate-700">Architecture v2.1:</span>
        <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-violet-500" />CORE (2)</span>
        <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-emerald-500" />FINANCIAL (3)</span>
        <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-red-500" />SECURITY (2)</span>
        <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-blue-500" />INFRASTRUCTURE (1)</span>
        <span className="ml-auto font-mono text-[10px] bg-white px-2 py-0.5 rounded border">Fused: G+S → GS | R+F → Resilience | Chaos → Monitor mode | Maint → Resilience module</span>
      </div>

      {/* Global Status */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm">
          <div className="flex items-center gap-2 mb-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-xs text-slate-400 uppercase font-bold tracking-wider">Fleet Status</span>
          </div>
          <div className="text-2xl font-extrabold text-slate-900">8/8</div>
          <div className="text-xs text-emerald-600 font-medium">{allActive ? "ALL ACTIVE" : "DEGRADED"}</div>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm">
          <div className="text-xs text-slate-400 uppercase font-bold tracking-wider mb-2">Autonomous Ops</div>
          <div className="text-2xl font-extrabold text-slate-900">{totalDecisions.toLocaleString()}</div>
          <div className="text-xs text-emerald-600 font-medium">+{globalOps} this session</div>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm">
          <div className="text-xs text-slate-400 uppercase font-bold tracking-wider mb-2">Avg CPU</div>
          <div className="text-2xl font-extrabold text-slate-900">{avgCpu}%</div>
          <div className="text-xs text-blue-600 font-medium">Optimal range</div>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm">
          <div className="text-xs text-slate-400 uppercase font-bold tracking-wider mb-2">Uptime</div>
          <div className="text-2xl font-extrabold text-slate-900">99.9%</div>
          <div className="text-xs text-emerald-600 font-medium">24/7 autonomous</div>
        </div>
      </div>

      {/* Agent Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
        {agents.map((agent) => {
          const tc = tierConfig[agent.tier];
          return (
            <div key={agent.id} className={`${tc.bg} border ${tc.border} rounded-xl p-4 hover:shadow-md transition-all`}>
              {/* Header */}
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-2">
                  <div className="relative">
                    <span className={`w-3 h-3 rounded-full ${tc.dot} inline-block`} />
                    <span className={`absolute inset-0 w-3 h-3 rounded-full ${tc.dot} animate-ping opacity-40`} />
                  </div>
                  <div>
                    <div className="text-sm font-bold text-slate-900 leading-tight">{agent.name}</div>
                    <div className="font-mono text-[10px] text-slate-400">AGENT-{String(agent.id).padStart(2, "0")}</div>
                  </div>
                </div>
                <div className="flex items-center gap-1.5 flex-col items-end">
                  <span className={`text-[9px] px-1.5 py-0.5 rounded-full font-bold ${tc.badge}`}>{agent.tier}</span>
                  {agent.subModules && (
                    <span className="text-[8px] text-slate-400 font-mono mt-0.5">
                      +{agent.subModules.length} modules
                    </span>
                  )}
                </div>
              </div>

              {/* Sub-modules badges (for fused agents) */}
              {agent.subModules && (
                <div className="flex flex-wrap gap-1 mb-2">
                  {agent.subModules.map((mod, mi) => (
                    <span key={mi} className="text-[8px] bg-white/60 text-slate-500 px-1.5 py-0.5 rounded font-medium">{mod}</span>
                  ))}
                </div>
              )}

              {/* Metrics */}
              <div className="grid grid-cols-3 gap-2 mb-3">
                <div className="bg-white/60 rounded-lg p-2 text-center">
                  <div className="text-[10px] text-slate-400">CPU</div>
                  <div className="font-mono text-xs font-bold text-slate-700">{agent.cpu.toFixed(1)}%</div>
                  <div className="h-1 bg-slate-100 rounded-full mt-1 overflow-hidden">
                    <div className={`h-full ${tc.dot} rounded-full transition-all`} style={{ width: `${Math.min(100, agent.cpu * 2)}%` }} />
                  </div>
                </div>
                <div className="bg-white/60 rounded-lg p-2 text-center">
                  <div className="text-[10px] text-slate-400">Memory</div>
                  <div className="font-mono text-xs font-bold text-slate-700">{agent.memory}MB</div>
                  <div className="h-1 bg-slate-100 rounded-full mt-1 overflow-hidden">
                    <div className={`h-full ${tc.dot} rounded-full transition-all`} style={{ width: `${Math.min(100, (agent.memory / 600) * 100)}%` }} />
                  </div>
                </div>
                <div className="bg-white/60 rounded-lg p-2 text-center">
                  <div className="text-[10px] text-slate-400">Decisions</div>
                  <div className="font-mono text-xs font-bold text-slate-700">{agent.decisions.toLocaleString()}</div>
                </div>
              </div>

              {/* Activity Stream */}
              <div className="space-y-1.5">
                <div className="flex items-center gap-2">
                  <svg className="w-3 h-3 text-emerald-500 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
                  <span className="text-[11px] text-slate-600 truncate">{agent.lastAction}</span>
                </div>
                <div className="flex items-center gap-2">
                  <svg className="w-3 h-3 text-blue-400 shrink-0 animate-spin" style={{ animationDuration: "3s" }} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" /></svg>
                  <span className="text-[11px] text-blue-600 truncate">{agent.nextAction}</span>
                </div>
              </div>

              {/* Activity Bar */}
              <div className="mt-2 h-4 bg-white/40 rounded-full overflow-hidden flex items-center gap-px">
                {Array.from({ length: 20 }).map((_, i) => (
                  <div
                    key={i}
                    className={`flex-1 rounded-full transition-all duration-300 ${tc.dot}`}
                    style={{
                      height: `${Math.max(20, Math.random() * 100)}%`,
                      opacity: Math.random() > 0.5 ? 0.6 : 0.25,
                    }}
                  />
                ))}
              </div>

              {/* Footer */}
              <div className="flex items-center justify-between mt-3 pt-2 border-t border-slate-100/50">
                <div className="flex items-center gap-1.5">
                  <span className="relative flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500" />
                  </span>
                  <span className="font-mono text-[10px] text-emerald-600 font-bold">{agent.uptime}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-[9px] text-slate-400 font-mono">#{agent.decisions.toLocaleString()}</span>
                  <span className="font-mono text-[10px] text-slate-400">{agent.heartbeat}ms</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
